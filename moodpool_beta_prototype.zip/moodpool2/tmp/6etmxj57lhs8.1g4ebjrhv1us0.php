<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<!-- Bootstrap -->
<link href="<?= ($BASE) ?>/<?= (UI) ?>/css/bootstrap.min.css" rel="stylesheet">	
	
<!-- MODAL-->
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	
<!-- Stylesheet CSS-->	
<link href="<?= ($BASE) ?>/<?= (UI) ?>/css/filtertest_style.css" rel="stylesheet" type="text/css">	
	
<!-- style MODAL 2-->	
<link href="<?= ($BASE) ?>/<?= (UI) ?>/css/lightbox.css" rel="stylesheet" type="text/css">
	
<!-- JavaScripts -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>	
<script src="<?= ($BASE) ?>/<?= (UI) ?>/js/prueba.js"></script>

<!-- JavaScripts MODAL -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="<?= ($BASE) ?>/<?= (UI) ?>/js/modal.js"></script>
	
<!-- JavaScripts MODAL 2-->	
<script type="text/javascript" src="<?= ($BASE) ?>/<?= (UI) ?>/js/lightbox.min.js"></script>
	
	
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

<script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>	
	
	

<title>Mood Pool ABOUT PAGE</title>	
	
</head>
<body>
<div id="wrapper">	
	<div class="row">
	<div class="col-md-12 text-margins" align="center">
		
		<h2 class="about-title text-insidemargins">ABOUT MOOD POOL</h2>	
		
		<p class="text-insidemargins about-text">MOOD POOL is a website for artists, creatives and procrastinators looking to explore different media <em>(music, photos, articles, videos, illustrations, animation etc.)</em>, customized to specific moods.</p> 

		<p class="text-insidemargins about-text">It is an essential tool for reference research for creative projects, allowing you to browse through different media types that fall into the same specified mood categories.</p>
		
		<hr>
		
		<h3 class="text-insidemargins about-text">HOW IT WORKS</h3>
		
		<p class="text-insidemargins about-text">To look at an specific mood type media, choose the desired mood as a filter on the <em>welcome page</em> or on the <em>mood pool page</em>. The site will then show you several options of different media tagged as your chosen mood.</p>
		
		<p class="text-insidemargins about-text">The website allows you to filter the content shown not only mood wise but also depending on the type of media.</p>
		
		<p class="text-insidemargins about-text">Scroll through and explore the different <em>mood pins</em>, save the ones you like by pressing the hear button on each pin.</p>
		
		<p class="text-insidemargins about-text">On your <em>profile page</em> you can access your previously saved <em>mood pins</em> and you can also upload images and urls, and tag them with specific mood tags.</p>
		
		
	</div>	
	</div>	
</div>	
</body>
</html>
