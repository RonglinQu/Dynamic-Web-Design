<!doctype html>
<html>
	<head>	
		<title>show image</title>	
	</head>
	<body>
		<img src="<?= ($thumb) ?>" />
		<form action = "<?= ($BASE) ?>/createnote" method = "post">
			<input type = "date" name = "notedate" />
			<input type = "time" name = "notetime" />
			<input type = "text" name = "notetitle" placeholder="title"/>
			<input type = "text" name = "note" placeholder="note"/>
			<input type = "hidden" name = "mediaid" value="<?= ($mediaid) ?>"/>
			<div class="checkbox">
				<?php foreach (($datalist?:[]) as $moodtype): ?>
					<li><input type="checkbox" name="mood[]" value="<?= ($moodtype['description']) ?>" /><?= ($moodtype['description']) ?></li>
				<?php endforeach; ?>
			</div>
			<input type = "submit" value = "create"/>
		</form>
	</body>
</html>
