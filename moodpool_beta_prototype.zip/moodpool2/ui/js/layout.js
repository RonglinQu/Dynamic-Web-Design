function signuphidden(){
	if(document.getElementById("loginout").innerHTML=="logout"){
		document.getElementById('signup').style.visibility = 'hidden';
	}else{
		document.getElementById('signup').style.visibility = 'visible';
	}
}
//180319 add by lydia --- display error message
function showError(){
	if($("#errormessage").html()==''){
		$(".displayerror").hide();
	}else{
		$(".displayerror").show();
	}
};
