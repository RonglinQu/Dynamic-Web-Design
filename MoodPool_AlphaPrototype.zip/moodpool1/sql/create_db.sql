CREATE TABLE `users` (
	`userid` int NOT NULL AUTO_INCREMENT,
	`username` varchar(100) NOT NULL,
	`password` varchar(100) NOT NULL,
	`email` varchar(100) NOT NULL,
	PRIMARY KEY (`userid`)
);

CREATE TABLE `moodtype` (
	`moodtypeid` int NOT NULL AUTO_INCREMENT,
	`description` varchar(100) NOT NULL,
	PRIMARY KEY (`moodtypeid`)
);

CREATE TABLE `collections` (
	`userid` int NOT NULL,
	`mediaid` varchar(100) NOT NULL,
	`uploaddate` DATE NOT NULL,
	`uploadtime` TIME NOT NULL,
	PRIMARY KEY (`userid`,`mediaid`)
);

CREATE TABLE `mediatype` (
	`typeid` int NOT NULL AUTO_INCREMENT,
	`description` varchar(100) NOT NULL,
	PRIMARY KEY (`typeid`)
);

CREATE TABLE `mediacollections` (
	`mediaid` varchar(100) NOT NULL,
	`mediatype` int NOT NULL,
	`title` varchar(100) NOT NULL,
	`url` varchar(500),
	`recommended` bool NOT NULL,
	`recomid` varchar(100),
	`count` int NOT NULL DEFAULT '1',
	`uploaddate` DATE NOT NULL,
	`uploadtime` TIME NOT NULL,
	`mediasource` varchar(500) NOT NULL,
	PRIMARY KEY (`mediaid`)
);

CREATE TABLE `recommendation` (
	`recomid` varchar(100) NOT NULL AUTO_INCREMENT,
	`userid` int NOT NULL,
	`title` varchar(100) NOT NULL,
	`uploaddate` DATE NOT NULL,
	`uploadtime` TIME NOT NULL,
	`url` varchar(500) NOT NULL,
	`mediatype` varchar(100) NOT NULL,
	`valid` bool NOT NULL DEFAULT 'true',
	PRIMARY KEY (`recomid`)
);

CREATE TABLE `personalmood` (
	`userid` int NOT NULL,
	`mediaid` varchar(100) NOT NULL,
	`mood` int NOT NULL,
	PRIMARY KEY (`userid`,`mediaid`)
);

CREATE TABLE `originalmoods` (
	`mediaid` varchar(100) NOT NULL,
	`moodtype` int NOT NULL,
	PRIMARY KEY (`mediaid`,`moodtype`)
);

ALTER TABLE `collections` ADD CONSTRAINT `collections_fk0` FOREIGN KEY (`userid`) REFERENCES `users`(`userid`);

ALTER TABLE `collections` ADD CONSTRAINT `collections_fk1` FOREIGN KEY (`mediaid`) REFERENCES `mediacollections`(`mediaid`);

ALTER TABLE `mediacollections` ADD CONSTRAINT `mediacollections_fk0` FOREIGN KEY (`mediatype`) REFERENCES `mediatype`(`typeid`);

ALTER TABLE `mediacollections` ADD CONSTRAINT `mediacollections_fk1` FOREIGN KEY (`recomid`) REFERENCES `recommendation`(`recomid`);

ALTER TABLE `recommendation` ADD CONSTRAINT `recommendation_fk0` FOREIGN KEY (`userid`) REFERENCES `users`(`userid`);

ALTER TABLE `personalmood` ADD CONSTRAINT `personalmood_fk0` FOREIGN KEY (`userid`) REFERENCES `collections`(`userid`);

ALTER TABLE `personalmood` ADD CONSTRAINT `personalmood_fk1` FOREIGN KEY (`mediaid`) REFERENCES `collections`(`mediaid`);

ALTER TABLE `personalmood` ADD CONSTRAINT `personalmood_fk2` FOREIGN KEY (`mood`) REFERENCES `moodtype`(`moodtypeid`);

ALTER TABLE `originalmoods` ADD CONSTRAINT `originalmoods_fk0` FOREIGN KEY (`mediaid`) REFERENCES `mediacollections`(`mediaid`);

ALTER TABLE `originalmoods` ADD CONSTRAINT `originalmoods_fk1` FOREIGN KEY (`moodtype`) REFERENCES `moodtype`(`moodtypeid`);


CREATE VIEW recommendinfo
AS SELECT R.*,MT.*,M.mediaid,M.count
FROM recommendation R, mediacollections M, originalmoods O, moodtype MT
WHERE M.recomid = R.recomid AND O.mediaid = M.mediaid
AND MT.moodtypeid = O.moodtype;

CREATE VIEW likedmediainfo
AS SELECT MC.*,C.userid, C.uploaddate AS userlikeddate, C.uploadtime AS userlikedtime, PM.mood
FROM mediacollections MC, collections C,personalmood PM
WHERE MC.mediaid = C.mediaid AND C.mediaid = PM.mediaid AND C.userid = PM.userid

CREATE VIEW userandmedia
AS SELECT MC.*,C.userid, C.uploaddate AS userlikeddate, C.uploadtime AS userlikedtime
FROM mediacollections MC, collections C
WHERE MC.mediaid = C.mediaid

alter table personalmood drop FOREIGN key personalmood_fk0;
alter table personalmood drop FOREIGN key personalmood_fk1;
alter table personalmood add foreign key (mediaid,userid) REFERENCES collections(mediaid,userid);

ALTER TABLE mediacollections MODIFY title VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE mediacollections MODIFY url VARCHAR(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE mediacollections MODIFY mediasource VARCHAR(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE recommendation MODIFY title VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE recommendation MODIFY url VARCHAR(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE users MODIFY username VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci;

INSERT INTO `mediatype` (`description`) VALUES ('image/jpeg');
INSERT INTO `mediatype` (`description`) VALUES ('image/png');
INSERT INTO `mediatype` (`description`) VALUES ('image/gif');

INSERT INTO moodtype (`description`) VALUES ('happy');
INSERT INTO moodtype (`description`) VALUES ('relaxed');
INSERT INTO moodtype (`description`) VALUES ('excited');
INSERT INTO moodtype (`description`) VALUES ('melancholy');
INSERT INTO moodtype (`description`) VALUES ('angry');
INSERT INTO moodtype (`description`) VALUES ('sad');
INSERT INTO moodtype (`description`) VALUES ('disappointed');
INSERT INTO moodtype (`description`) VALUES ('cheerful');
INSERT INTO moodtype (`description`) VALUES ('curious');
INSERT INTO moodtype (`description`) VALUES ('lonely');
INSERT INTO moodtype (`description`) VALUES ('fearful');
INSERT INTO moodtype (`description`) VALUES ('silly');
INSERT INTO moodtype (`description`) VALUES ('surprised');
INSERT INTO moodtype (`description`) VALUES ('geeky');
INSERT INTO moodtype (`description`) VALUES ('bored');
INSERT INTO moodtype (`description`) VALUES ('paranoid');
INSERT INTO moodtype (`description`) VALUES ('contemplative');
INSERT INTO moodtype (`description`) VALUES ('weird');
INSERT INTO moodtype (`description`) VALUES ('loving');
INSERT INTO moodtype (`description`) VALUES ('hopeful');

