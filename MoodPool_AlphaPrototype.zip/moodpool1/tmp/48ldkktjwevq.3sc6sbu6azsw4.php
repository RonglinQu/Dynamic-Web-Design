<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <title></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script language="javascript" type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>js/p5/p5.min.js"></script>
    <script language="javascript" type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>js/sketches/particles.js"></script>
	<script language="javascript" type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>js/welcome.js"></script>

    <link href="<?= ($BASE) ?>/<?= ($UI) ?>css/landing.css" rel="stylesheet">
  </head>
  
  <body>
	<div> <a href="<?= ($BASE) ?>/welcome" class="clickable"><img src="<?= ($BASE) ?>/<?= ($UI) ?>images/MP_logo_v2.png" class="img-logo"/></a> </div>
  <div id='report'>
    <h3> <a href="<?= ($BASE) ?>/show_report">Report</a> </h3>
  </div>
  <div class="main">  <!-- Ronglin modified 180304 -->
    <p class="choose-moodei choose">CHOOSE YOUR MOOD</p>
        <br>
        <p class="choose-moodei moodei">Are you
          <span class="word wisteria">happy?</span>
          <span class="word belize">worried?</span>
          <span class="word pomegranate">excited?</span>
          <span class="word green">angry?</span>
          <span class="word midnight">hopeful?</span>
        </p>
    <div class="search-corner">
	  <!-- <h4 id = "user">
		<a href="<?= ($BASE) ?>/<?= ($username) ?>/home" target="_blank"><?= ($username) ?></a>
    </h4> -->

      <div class="search-box">
        <form method="post" name="form" autocomplete="off" action="<?= ($BASE) ?>/search">
          <input type="text" id="tag" name="tag" placeholder="Search Moods">
          <button type="submit">Search</button>
        </form>
      </div>
      <p id = "login">
        Or<br>
      		<a href="<?= ($BASE) ?>/login" target="_self">login</a>
      		<a href="<?= ($BASE) ?>/signup" target="_self">signup</a>
      </p>
      <p id = "logout"> <a href="<?= ($BASE) ?>/logout" target="_self">logout</a> </p>
      </div>
      
    <h4 id = "user"  class="search-box">
    <a href="<?= ($BASE) ?>/<?= ($username) ?>/home" target="_self"><?= ($username) ?></a>
    </h4>
  </div>




	  <script type="text/javascript">
		userhidden("<?= ($user) ?>","<?= ($login) ?>","<?= ($logout) ?>");
	  </script>

	<script language="javascript" type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>js/sketches/script.js"></script>
  </body>
</html>
