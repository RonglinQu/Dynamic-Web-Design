<!DOCTYPE html>
<html>
   <head>
      <title><?= ($html_title) ?></title>
      <meta charset='utf8' />
   </head>
   <body>
      <?= ($result) ?>  <a href=''>Return</a>
   </body>
</html>
