var base_path = '/~s1734032/moodpool2';

$(function(){
	$("#form_signup").submit(function(event){
		event.preventDefault();
		var email = document.getElementById("email_sp").value;
		var username = document.getElementById("username_sp").value;
		var pwd = document.getElementById("password_sp").value;
		var data = JSON.stringify({ email:email,username:username,pwd:pwd});
		var path = base_path.concat('/signup');
		$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { data : data }, 
				datatype: 'json',
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res['result']){
						var redirect = base_path.concat(res['redirect']);
						window.location.href = redirect;
					}else{
						$(".displayerror_signup").show();
						document.getElementById("errormessage_signup").innerHTML = res['error'];
						document.getElementById("email_sp").value = '';
						document.getElementById("password_sp").value = '';
						document.getElementById("username_sp").value = '';
					}
				}
			}
		);
	});
});

$(document).ready(function(){
	$(".displayerror_signup").hide();
});

function displayerror_signup(){
	$(".displayerror_signup").show();
	document.getElementById("errormessage_signup").innerHTML = 'fields cannot be empty';
}


