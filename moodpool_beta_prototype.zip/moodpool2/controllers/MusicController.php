<?php


class MusicController {
	
	private $lastfm_key = "6d77ced8e14998cc8e93f6c5d2de5050";
	private $number_per_page = 20;
	private $moodvariable;
	
	public function __construct() {
		global $f3;
		$this->moodvariable = new DB\SQL\Mapper($f3->get('DB'),"moodvariable");		 
	}
	
	public function makingRequest($tag,$page) {
		
		global $f3;
		$moodtype = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		$moodtype->load(array("description=?",$tag));
		$this->moodvariable->load(array("moodtypeid=?",$moodtype->moodtypeid));
		$valence = $this->moodvariable->valence+$page;
		$arousal = $this->moodvariable->arousal+$page;
		$request =  "http://musicovery.com/api/V5/playlist.php?&fct=getfrommood&".
					"popularitymax=100&popularitymin=0&trackvalence=".$valence.
					"&trackarousal=".$arousal.
					"&resultsnumber=".$this->number_per_page;
		return $request;
	}
	
	public function load($request) {
		// for more on cURL see http://php.net/manual/en/book.curl.php and http://blog.unitedheroes.net/curl/
		$crl = curl_init(); // creating a curl object
		$timeout = 10;
		curl_setopt ($crl, CURLOPT_URL,$request);
		curl_setopt ($crl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($crl, CURLOPT_CONNECTTIMEOUT, $timeout);
		
		$xml_to_parse = curl_exec($crl);

		curl_close($crl); // closing the crl object
		
		$parsed_xml = simplexml_load_string($xml_to_parse,null,LIBXML_NOCDATA);
		$items = $parsed_xml->tracks->track; // traversing the xml nodes to count how many photos were retrieved

		//echo htmlspecialchars($xml_to_parse);//show XML

		return $items;
	}
	
	public function getingMusic($items){
		
		$numOfMusics = count($items);
		$returnrecord = array();
		$img = array();
		$musicbymood = array();
		if($numOfMusics>0){ // yes, some items were retrieved
			foreach($items as $current){
				$record = array();
				$record["tracktitle"] = $current->title;
				$record["artist"] = $current->artist->name;
				array_push($musicbymood,$record);
			}
		}
		//get track cover and url
		$returnrecord = $this->getCover($musicbymood);
		return $returnrecord;
	}
	
	private function getCover($dataset){
		global $f3;
		$crl_container = array();
		$returnarray = array();
		foreach($dataset as $item){
			$request =  "http://ws.audioscrobbler.com/2.0/?method=track.getInfo&".
						"api_key=".$this->lastfm_key."&artist=".$item["artist"]."&track=".$item["tracktitle"]."&format=json";
			$crl = curl_init();
			curl_setopt ($crl, CURLOPT_URL,$request);
			curl_setopt ($crl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt ($crl, CURLOPT_CONNECTTIMEOUT, $timeout);
			array_push($crl_container,$crl);
		}
		$crl_set = curl_multi_init();
		foreach($crl_container as $item){
			curl_multi_add_handle($crl_set,$item);
		}
		//execute the handles
		do {
			curl_multi_exec($crl_set,$running);
		} while($running > 0);
		
		foreach ($crl_container as $item) {
			$temp =  json_decode(curl_multi_getcontent($item),true);
			$record["url"] = $temp["track"]["url"];
			$record["artist"] = $temp["track"]["artist"]["name"];
			$record["title"] = $temp["track"]["name"];
			$record["img"] = $temp["track"]["album"]["image"][3]["#text"];
			$record["album"] = $temp["track"]["album"]["title"];
			if(!empty($record["url"])){
				array_push($returnarray,$record);
			}
			if(empty($record["img"])){
				$record["img"] = $f3->get("UPLOAD")."/thumb/NoCover.png";
			}
		}
		return $returnarray;
		
	}

	public function addFavorite($music){
		global $f3;
		$mediacollections=new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		$collections = new DB\SQL\Mapper($f3->get('DB'),"collections");
		$predefined = new DB\SQL\Mapper($f3->get('DB'),"originalmoods");
		$personaldefined = new DB\SQL\Mapper($f3->get('DB'),"personalmood");
		$mediatype = new DB\SQL\Mapper($f3->get('DB'),"mediatype");
		$moodtype = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		$moodid = $moodtype->load(array('description=?',$music['moodtag']));
		$mediaid = NULL;
		if($this->checkURL($music['resource'])){
			$mediacollections->load(array('mediasource=?',$music['resource']));
			$mediaid = $mediacollections->mediaid;
			if($collections->count(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']))>0){
				if($personaldefined->count(array('userid=? AND mediaid=? AND mood=?',$_SESSION['userinfo']['userid'],$mediacollections->mediaid,$moodid['moodtypeid']))==0){
					$personaldefined->mediaid = $mediacollections->mediaid;
					$personaldefined->mood = $moodid['moodtypeid'];
					$personaldefined->userid = $_SESSION['userinfo']['userid'];
					$personaldefined->save();
				}
			}else{
				$collections->userid = $_SESSION['userinfo']['userid'];
				$collections->mediaid = $mediacollections->mediaid;
				$collections->uploaddate = date('Ymd');
				$collections->uploadtime = date("H:i:s");
				$collections->save();
				$personaldefined->mediaid = $mediacollections->mediaid;
				$personaldefined->mood = $moodid['moodtypeid'];
				$personaldefined->userid = $_SESSION['userinfo']['userid'];
				$personaldefined->save();
				$mediacollections->count++;
				$mediacollections->save();
			}
			if($predefined->count(array('mediaid=? AND moodtype=?',$mediacollections->mediaid,$moodid['moodtypeid']))==0){
				$predefined->mediaid = $mediacollections->mediaid;
				$predefined->moodtype = $moodid['moodtypeid'];
				$predefined->save();
			}

		}else{
			$mediacollections->mediaid = strtoupper(md5(uniqid(rand(),true)));
			$mediaid = $mediacollections->mediaid;
			$mediatypeid = $mediatype->load(array('description=?',"music"));
			$mediacollections->mediatype = $mediatypeid['typeid'];
			$mediacollections->url = $music['cover'];
			$mediacollections->recommended = false;
			$mediacollections->uploaddate = date('Ymd');
			$mediacollections->uploadtime = date("H:i:s");
			$mediacollections->mediasource = $music['resource'];
			$mediacollections->title = $music['title'];
			$mediacollections->artist = $music['artist'];
			
			$collections->userid = $_SESSION['userinfo']['userid'];
			$collections->mediaid = $mediacollections->mediaid;
			$collections->uploaddate = $mediacollections->uploaddate;
			$collections->uploadtime = $mediacollections->uploadtime;
			
			$predefined->mediaid = $mediacollections->mediaid;
			$predefined->moodtype = $moodid['moodtypeid'];
			
			$personaldefined->userid = $collections->userid;
			$personaldefined->mediaid = $collections->mediaid;
			$personaldefined->mood = $predefined->moodtype;
			
			$mediacollections->save();
			$collections->save();
			$predefined->save();
			$personaldefined->save();
		}
		return $mediaid;
	}
	
	private function checkURL($resource){
		global $f3;
		$mediacollections=new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		if($mediacollections->count(array('mediasource=?',$resource))==0){
			return 0;
		}else{
			return 1;
		}
	}
	
	public function checkLiked($resource){
		global $f3;
		$userandmedia=new DB\SQL\Mapper($f3->get('DB'),"userandmedia");
		$userandmedia->load(array('mediasource=? AND userid=?',$resource,$_SESSION['userinfo']['userid']));
		if($userandmedia->dry()){
			return ;
		}else{
			return $userandmedia->mediaid;
		}
	}
	
	public function unlike($mediaid) {
		global $f3;
		$mediacollections = new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		$collections = new DB\SQL\Mapper($f3->get('DB'),"collections");
		$personaltags = new DB\SQL\Mapper($f3->get('DB'),"personalmood");
		$notemapper = new DB\SQL\Mapper($f3->get('DB'),"notes"); //180313 add by lydia
		$mediacollections->load(['mediaid=?',$mediaid]);							// load DB record matching the given ID	
		$collections->load(array('mediaid=? AND userid =?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
		$personaltags->load(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
		while(!$personaltags->dry()){
			$personaltags->erase();
			$personaltags->next();
		}
		$collections->erase();
		if($mediacollections->count>1){
			$mediacollections->count--;
			$mediacollections->save();
			/*180313 add by lydia start: delete the notes of this user*/
			$noteset = $notemapper->find(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
			$nc = new NoteController;
			foreach($noteset as $note){
				$nc->deleteNote($note->noteid);
			}
			/*180313 add by lydia end*/
		}else{
			$originalmoods = new DB\SQL\Mapper($f3->get('DB'),"originalmoods");
			$originalmoods->load(array('mediaid=?',$mediacollections->mediaid));
			while(!$originalmoods->dry()){
				$originalmoods->erase();
				$originalmoods->next();
			}
			/*180313 add by lydia start: delete the notes of this user*/
			$noteset = $notemapper->find(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
			$nc = new NoteController;
			foreach($noteset as $note){
				$nc->deleteNote($note->noteid);
			}
			/*180313 add by lydia end*/
			$mediacollections->erase();
		}
	}
	public function getLiked($picID=0) {
		global $f3;
		$returnData = array();
		$likedpic=new DB\SQL\Mapper($f3->get('DB'),"userandmedia");	// create DB query mapper object
		$moodtags = new DB\SQL\Mapper($f3->get('DB'),"personalmood");
		$moodtype = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		if ($picID == 0) {
			$data_list = $likedpic->find(array('userid=? AND mediatype IN ("4")',$_SESSION['userinfo']['userid']));
			foreach ($data_list as $record) {
				$recordData = array();
				$tags_list = array();
				$tags=array();
				$recordData["title"] = $record["title"];
				$recordData["mediatype"] = $record["mediatype"];
				$recordData["img"] = $record["url"];
				$recordData["url"] = $record["mediasource"];
				$recordData["mediaid"] = $record["mediaid"];
				$tags_list = $moodtags->find(array("userid=? AND mediaid=?",$_SESSION['userinfo']['userid'],$record['mediaid']));
				foreach($tags_list as $moodtag){
					$moodtype->load(array('moodtypeid=?',$moodtag["mood"]));
					array_push($tags,$moodtype["description"]);
				}
				$recordData["tags"] = $tags;
				array_push(	$returnData, $recordData);
			}
			return $returnData;
		}
		$likedpic->load(array('mediaid=? AND userid=? AND mediatype IN ("4")',$picID,$_SESSION['userinfo']['userid']));
		$recordData = array();
		$tags_list = array();
		$tags = array();
		$recordData["title"] = $likedpic["title"];
		$recordData["mediatype"] = $likedpic["mediatype"];
		$recordData["img"] = $record["url"];
		$recordData["url"] = $record["mediasource"];
		$recordData["mediaid"] = $record["mediaid"];
		$tags_list = $moodtags->find(array("userid=? AND mediaid=?",$_SESSION['userinfo']['userid'],$record['mediaid']));
		foreach($tags_list as $moodtag){
			$moodtype->load(array('moodtypeid=?',$moodtag["mood"]));
			array_push($tags,$moodtype["description"]);
		}
		$recordData["tags"] = $tags;
		return $recordData;
	}
	
}

?>
