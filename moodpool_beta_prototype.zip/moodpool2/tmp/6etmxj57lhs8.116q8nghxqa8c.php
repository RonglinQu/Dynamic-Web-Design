<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<!-- Stylesheet CSS-->	
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<link href="<?= ($BASE) ?>/<?= ($UI) ?>/css/MP_login.css" rel="stylesheet" type="text/css">
		<!--180310 add by lydia-->
		<link href="<?= ($BASE) ?>/<?= ($UI) ?>/css/pwd_icon.css" rel="stylesheet" type="text/css">
		<!-- JavaScripts -->	
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>	
		<!--180319 add by lydia -->
		<script src="<?= ($BASE) ?>/<?= ($UI) ?>/js/login.js"></script>
		<script src="<?= ($BASE) ?>/<?= ($UI) ?>/js/signup.js"></script>		
		<!--180310 add by lydia-->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
		<title>Login and Sign Up</title>
	</head>
	<body>
	<div class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="flip">
					<div class="card"> 
						<div class="face front"> 
							<div class="panel panel-default">
								<form class="form-horizontal" id="form_signup" name="form_signup">
									<br>
									<a href="<?= ($BASE) ?>/welcome"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/MP_logo_v2.png" class="img-logo resize-logo"/></a>
									<br>
									<label>Create New User</label>
									<input name="email" id="email_sp" class="form-control" placeholder="Email" oninvalid="displayerror_signup()" required/>
									<input name="username" id="username_sp" class="form-control" placeholder="Username" oninvalid="displayerror_signup()" required/>
									<!--180310 modify by lydia-->
									<input type="password" id="password_sp" name="password" class="form-control password" placeholder="Password" data-toggle="password" oninvalid="displayerror_signup()" required/>
									<br>
									<button type="submit" class="btn btn-primary btn-block">SIGN UP</button>
									<p class="text-center">
										<a href="#" class="fliper-btn">Already have an account?</a>
									</p>
									<!--180319 add by lydia start -->
									<!-- Newly added error-->		  
									<br>				  
									<div class="error-text displayerror_signup">
										<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
										<strong>  Error!</strong> <label id='errormessage_signup'></label>
									</div>
									<!--180319 add by lydia end -->
								</form>
							</div>
						</div> 
						<div class="face back"> 
							<div class="panel panel-default">
								<form class="form-horizontal" id="form_login" name="form_login">
									<br>
									<a href="<?= ($BASE) ?>/welcome"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/MP_logo_v2.png" class="img-logo resize-logo"/></a>
									<br>
									<input name="usernameemail" id="usernameemail" class="form-control" placeholder="Username or Email address" oninvalid="displayerror()" required/>
									<!--180310 modify by lydia-->
									<input type="password" id="password" name="password" class="form-control password" placeholder="Password" data-toggle="password" oninvalid="displayerror()" required/>
									<br>
									<!-- <p class="text-right"><a href="">Forgot Password</a></p> -->
									<button type= "submit" class="btn btn-primary btn-block">LOG IN</button>
									<hr>
									<p class="text-center">
										<a href="#" class="fliper-btn">Create new account?</a>
									</p>
									<!--180319 add by lydia start -->
									<!-- Newly added error-->		  
									<br>				  
									<div class="error-text displayerror_login">
										<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
										<strong>  Error!</strong> <label id='errormessage_login'></label>
									</div>
									<!--180319 add by lydia end -->									
								</form>
							</div>
						</div>
					</div>   
				</div>
			</div>
			<div class="col-md-4"></div>
		</div>
	</div>

	</body>
	<script type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>/js/login.js"></script>
	<script type="text/javascript">
		$(".password").password('toggle');
	</script>
</html>
