<?php

  /////////////////////////////////////
 // index.php for moodpool website //
/////////////////////////////////////

// Create f3 object then set various global properties of it
// These are available to the routing code below, but also to any 
// classes defined in autoloaded definitions
// the following code is modified from SimpleExample app
//180310 lydia add upload via URL
//180312 lydia add show image with note functions (add, modify, delete)
//180316 lydia add load more function
//180316 lydia add predictive search on welcome page

$f3 = require('lib/base.php');

// autoload Controller class(es) and anything hidden above web root, e.g. DB stuff
$f3->set('AUTOLOAD','controllers/');		

$db = DatabaseConnection::connect();		// defined as autoloaded class in AboveWebRoot/autoload/
$f3->set('DB', $db);

$f3->set('DEBUG',3);		// set maximum debug level
$f3->set('UI','ui/');		// folder for View templates
$f3->set('UPLOADS','data/image/'); //folder for uploaded images
$f3->set('TEMP','tmp/'); //folder for temp files
session_start();

  /////////////////////////////////////////////
 // moodpool website routings //
/////////////////////////////////////////////

//home page (index.html) -- actually just shows form entry page with a different title
$f3->redirect('GET /','/welcome');
$f3->route('GET /welcome',
	function($f3){
		/*$f3->set('html_title','welcome');
		$f3->set("content","welcome.html");
		$md = new Mooddb;
		$moodtags = $md->getMood();
		$f3->set('moodtags', $moodtags);
		if(empty($_SESSION['userinfo']['username'])){
			$f3->set('loginorout','login');
		}else{
			$f3->set('username',$_SESSION['userinfo']['username']);
			$f3->set('loginorout','logout');
		}*/
		if(empty($_SESSION['userinfo']['username'])){
			$f3->set('login','visible');
			$f3->set('user','hidden');
			$f3->set('logout','hidden');
		}else{
			$f3->set('login','hidden');
			$f3->set('user','visible');
			$f3->set('logout','visible');
			$f3->set('username',$_SESSION['userinfo']['username']);
		}
		echo template::instance()->render('welcome.html');
	}
);
$f3->route('GET /signup',
	function($f3) {
		$f3->set('html_title','signup');
		//$f3->set('content','signup.html');
		//$f3->set('action','signup');
		$f3->set('loginorout','login');
		//echo template::instance()->render('layout.html');
		echo template::instance()->render('signup.html');
	}
);
$f3->route('POST /signup',
	function($f3){
		$success = true;
		$formdata = array();			// array to pass on the entered data in
		$formdata["username"] = $f3->get('POST.username');		// whatever was called "username" on the form
		$formdata["password"] = $f3->get('POST.password');		// whatever was called "password" on the form
		$formdata["email"] = $f3->get('POST.email');		// whatever was called "password" on the form
		$controller = new Userdb;
		if(empty($formdata["username"])||empty($formdata["password"])||empty($formdata["email"])){
			$result = "fields cannot be empty ";
			$success = false;
		}else if(!$controller->checkUserName($formdata["username"])){
			$result = "'@'can not be included in a username ";
			$success = false;
		}else if(!$controller->checkUserEmail($formdata["email"])){
			$result = "not a valid email address ";
			$success = false;
		}else{
			$result = $controller->putIntoDatabase($formdata);
			$userinfo = $controller->getUserInfo($formdata["username"]);

			$f3->set('html_title','response');
			$f3->set('content','response.html');
			switch($result){
				case 1:
					//$f3->set('result','this username exists, please enter a new username');
					$result = "this username exists, please enter a new username ";
					$f3->set('loginorout','login');
					$success = false;
					break;
				case 2:
					//$f3->set('result','this email exists, please enter a new email address');
					$result = "this email exists, please enter a new email address ";
					$f3->set('loginorout','login');
					$success = false;
					break;
				case 0:
					//$f3->set('result','success');
					$f3->set('loginorout','logout');
					$_SESSION['userinfo'] = array(
						'username' => $userinfo["username"],
						'userid' => $userinfo["userid"],
						'email' => $userinfo["email"]
					);
					break;
			}
		}
		
		if($success){
			$f3->reroute('/welcome');
		}else{
			$f3->set('result',$result);
			echo template::instance()->render('layout.html');
		}
	}
);
$f3->route('GET /login',
	function($f3) {
		$f3->set('html_title','login');
		//$f3->set('content','login.html');
		//$f3->set('action','login');
		$f3->set('loginorout','login');
		//echo template::instance()->render('layout.html');
		echo template::instance()->render('login.html');
	}
);

$f3->route('POST /login',
	function($f3){
		$success = true;
		$formdata = array();			// array to pass on the entered data in
		$formdata["usernameemail"] = $f3->get('POST.usernameemail');		// whatever was called "username" on the form
		$formdata["password"] = $f3->get('POST.password');		// whatever was called "password" on the form
			
		$controller = new Userdb;
		$result = $controller->checkUserInfo($formdata);
		$userinfo = $controller->getUserInfo($formdata["usernameemail"]);

		$f3->set('html_title','response');
		$f3->set('content','response.html');
		switch ($result) {
			case 0:
				$f3->set('result','Success');
				$f3->set('loginorout','logout');
				$_SESSION['userinfo'] = array(
					'username' => $userinfo['username'],
					'userid' => $userinfo['userid'],
					'email' => $userinfo['email']
				);
				break;
			case 1:
				//$f3->set('result','The username or email address does not exist. Please check your username or email address');
				$result = "The username or email address does not exist. Please check your username or email address";
				$f3->set('loginorout','login');
				$success = false;
				break;
			case 2:
				//$f3->set('result','The password is wrong.');
				$result = "The password is wrong.";
				$f3->set('loginorout','login');
				$success = false;
				break;
		}
		//echo template::instance()->render('layout.html');
		if($success){
			$f3->reroute('/welcome');
		}else{
			$f3->set('result',$result);
			echo template::instance()->render('layout.html');
		}
	}
);

$f3->route('GET /logout',
	function($f3) {
		session_destroy();
		$f3->reroute('/welcome');
	}
);

$f3->route('GET /@username/home',
	function($f3) {
		$f3->set('html_title','MyHome');
		$f3->set('content','profile.html');
		$f3->set('loginorout','logout');
		$f3->set('username',$_SESSION['userinfo']['username']);
		$is = new ImageServer;
		$info = $is->getUpload(0);
		$f3->set('likeddatalist', $info);
		$likedimages = $is->getLiked(0);
		$f3->set('likedimages',$likedimages);
		$md = new Mooddb;
		$datalist = $md->getMood();
		$f3->set('datalist', $datalist);
		//var_dump($likedimages);
		echo template::instance()->render('layout.html');
	}
);

$f3->route('POST|GET /upload',
	function($f3) {
		$f3->set('html_title','upload');
		$f3->set('content','upload.html');
		$f3->set('loginorout','logout');
		$f3->set('username',$_SESSION['userinfo']['username']);
		$md = new Mooddb;
		$datalist = $md->getMood();
		$f3->set('datalist', $datalist);
		echo template::instance()->render('layout.html');
	}
);

$f3->route('POST /uploadImage',
	function($f3) {
		$is = new ImageServer;
		if ($filedata = $is->upload()) {						// if this is null, upload failed	
			$f3->set('filedata', $filedata);
		
			$f3->set('html_title','Image Server Home');
			$f3->set('content','profile.html');
			$f3->set('loginorout','logout');
			$f3->set('username',$_SESSION['userinfo']['username']);
			//echo template::instance()->render('layout.html');
			$f3->reroute('/'.$_SESSION['userinfo']['username'].'/home');
		}
	}
);

//180310 add by lydia
$f3->route('POST /uploadurl',
	function($f3){
		$dataset = array();
		$dataset['url'] = $f3->get('POST.urllink');
		$dataset['picname'] = $f3->get('POST.picname');
		$dataset['moodtags'] = $f3->get('POST.mood');
		if (empty($dataset['moodtags'])){
			echo "Please select at least one mood tag <a href=''>Return</a>";
		}else{
			$is = new ImageServer;
			$result = $is->uploadurl($dataset);
			if ($result) {		
				$f3->reroute('/'.$_SESSION['userinfo']['username'].'/home');
			}else{
				echo "upload error";
			}
		}
	}
);

/*$f3->route('GET /viewimages',
  function($f3) {
  	$is = new ImageServer;
    $uploadimages = $is->getUpload(0);
    $f3->set('datalist', $uploadimages);
	$likedimages = $is->getLiked(0);
	$f3->set('likedimages',$likedimages);
	$f3->set('content', 'viewimages.html');
	$f3->set('loginorout','logout');
	$f3->set('username',$_SESSION['userinfo']['username']);
	echo template::instance()->render('layout.html');    
  }
);*/

// For GET delete requests, we show the viewimages page again, now without the deleted image
$f3->route('GET /delete/@id',
  function($f3) {
	$is = new ImageServer;
	$is->deleteService($f3->get('PARAMS.id'));
	$f3->set('username',$_SESSION['userinfo']['username']);
	$f3->reroute('/'.$_SESSION['userinfo']['username'].'/home');
  }
);

// For POST delete requests (presumably AJAX), we do not output any page content
$f3->route('POST /delete/@id',
  function($f3) {
	$is = new ImageServer;
	$is->deleteService($f3->get('PARAMS.id'));
  }
);

$f3->route('GET /search/@tag',
  function($f3){

	$md = new Mooddb();
	$moodtag = $f3->get('PARAMS.tag');
	if($md->checkMood($moodtag)){
		echo "The mood entered does not exist, please choose a new one";
	}else{
		$fapi = new FlickrAPI;
		$request = $fapi->makingRequest($moodtag,1);
		$items = $fapi->load($request);
		$link_list = $fapi->getingPictures($items);
		$is = new ImageServer();
		for($i=0;$i<count($link_list);$i++){
			$mediaid = $is->checkLiked($link_list[$i]['img']);
			if(!empty($mediaid)){
				$link_list[$i]['liked']=true;
				$link_list[$i]['mediaid'] = $mediaid;
			}else{
				$link_list[$i]['liked']=false;
				$link_list[$i]['mediaid'] = "";
			}
		}
	}
	$moodlist = $md->getMood();
	$f3->set('moodlist',$moodlist);
	$f3->set('content', 'searchresult.html');
	$f3->set('searchresult', $link_list);
	$f3->set('mood',$moodtag);
	if(empty($_SESSION['userinfo']['username'])){
		$f3->set('loginorout','login');
	}else{
		$f3->set('loginorout','logout');
		$f3->set('username',$_SESSION['userinfo']['username']);
	}
	echo template::instance()->render('layout.html'); 
  }
);

$f3->route('POST /search',
  function($f3){
	$moodtag = $f3->get('POST.tag');
	$md = new Mooddb();
	if($md->checkMood($moodtag)){
		echo "The mood entered does not exist, please choose a new one";
	}else{
		$fapi = new FlickrAPI;
		$request = $fapi->makingRequest($moodtag,1);
		$items = $fapi->load($request);
		$link_list = $fapi->getingPictures($items);
		$is = new ImageServer();
		for($i=0;$i<count($link_list);$i++){
			$mediaid = $is->checkLiked($link_list[$i]['img']);
			if(!empty($mediaid)){
				$link_list[$i]['liked']=true;
				$link_list[$i]['mediaid'] = $mediaid;
			}else{
				$link_list[$i]['liked']=false;
				$link_list[$i]['mediaid'] = "";
			}
		}
	}
	$moodlist = $md->getMood();
	$f3->set('moodlist',$moodlist);
	$f3->set('content', 'searchresult.html');
	$f3->set('searchresult', $link_list);
	$f3->set('mood',$moodtag);
	if(empty($_SESSION['userinfo']['username'])){
		$f3->set('loginorout','login');
	}else{
		$f3->set('loginorout','logout');
		$f3->set('username',$_SESSION['userinfo']['username']);
	}
	echo template::instance()->render('layout.html');
  }
);

$f3->route('POST /like',
	function($f3){
		$response=array();
		if(empty($_SESSION['userinfo']['userid'])){
			$response['result'] = 0;
			$response['message'] = "please login or signup \n<form name=\"form2\" action=\"".
				 $f3->get('BASE')."/login\" method=\"get\">".
				 "<input type=\"submit\" value=\"login\"/></form><form name=\"form2\" action=\"".
				 $f3->get('BASE')."/signup\" method=\"get\">".
				 "<input type=\"submit\" value=\"signup\"/></form>";
		}else{
			$image = json_decode($f3->get('POST.imageinfo'),true);
			$is = new ImageServer();
			$mediaid = $is->addFavorite($image);
			$response['result'] = 1;
			$response['message'] = $mediaid;
		}
		echo json_encode($response);
	}
);

$f3->route('GET /unlike/@mediaid',
	function($f3){
		$is = new ImageServer;
		$is->unlike($f3->get('PARAMS.mediaid'));
		$f3->reroute('/'.$_SESSION['userinfo']['username'].'/home');
	}
);

$f3->route('POST /unlike',
	function($f3){
		$mediaid = json_decode($f3->get('POST.mediaid'),true);
		$is = new ImageServer();
		$is->unlike($mediaid['mediaid']);
		echo 1;
	}
);
$f3->route('GET /show_report',
	function($f3){
		echo template::instance()->render('report.html');
	}
);

//180312 add by lydia
$f3->route('GET /notetest',
	function($f3){
		$f3->set('html_title','MyHome');
		$f3->set('content','note.html');
		$f3->set('loginorout','logout');
		$f3->set('username',$_SESSION['userinfo']['username']);
		$is = new ImageServer;
		$info = $is->getUpload(0);
		$f3->set('likeddatalist', $info);
		$likedimages = $is->getLiked(0);
		$f3->set('likedimages',$likedimages);
		$md = new Mooddb;
		$datalist = $md->getMood();
		$f3->set('datalist', $datalist);
		//var_dump($likedimages);
		echo template::instance()->render('layout.html');
	}
);

//180312 add by lydia
$f3->route('GET /createnote',
	function($f3){
		$mediaid = $f3->get('GET.mediaid');
		$is = new ImageServer;
		$img = $is->getImageViaMediaid($mediaid);
		$f3->set('mediaid',$mediaid);
		$f3->set('img',$img['img']);
		$f3->set('thumb',$img['thumbnail']);
		$md = new Mooddb;
		$moodlist = $md->getMood();
		$f3->set('datalist', $moodlist);
		echo template::instance()->render('createnotes.html');
	}
);

//180312 add by lydia
$f3->route('POST /createnote',
	function($f3){
		//make sure all required information is not null
		$success = true;
		$data = array();
		$data['mediaid'] = $f3->get('POST.mediaid');
		if(empty($data['mediaid'])){
			$success = false;
		}
		if(empty($_SESSION['userinfo']['userid'])){
			$success = false;
		}
		$data['notetext'] = $f3->get('POST.note');
		$data['notetitle'] = $f3->get('POST.notetitle');
		$data['notedate'] = $f3->get('POST.notedate');
		$data['notetime'] = $f3->get('POST.notetime');
		$data['mood'] = $f3->get('POST.mood');
		$nc = new NoteController;
		$nc->putIntoDatabase($data);
		if(success){
			//$f3->reroute('/'.$_SESSION['userinfo']['username'].'/home');
			$f3->reroute('/displaynotes');
		}
		
	}
);

//180312 add by lydia
$f3->route('POST /displaynotes',
	function($f3){
		$nc = new NoteController;
		$noteset = $nc->getNotes($f3->get('POST.mediaid'));
		$f3->set('datalist',$noteset);
		echo template::instance()->render('shownotes.html');
	}
);

//180312 add by lydia
$f3->route('GET /displaynotes',
	function($f3){
		$nc = new NoteController;
		$noteset = $nc->getNotes("");
		$f3->set('datalist',$noteset);
		echo template::instance()->render('shownotes.html');
	}
);

//180313 add by lydia
$f3->route('GET /modifynote',
	function($f3){
		$noteid = $f3->get('GET.noteid');
		$nc = new NoteController;
		$mediaid = $nc->getMediaid($noteid);
		$is = new ImageServer;
		$img = $is->getImageViaMediaid($mediaid);
		$f3->set('mediaid',$mediaid);
		$f3->set('img',$img['img']);
		$f3->set('thumb',$img['thumbnail']);
		$note = $nc->getNoteInfo($noteid);
		$f3->set('notedate',date_format(date_create($note['notedate']),"Y-m-d"));
		$f3->set('notetime',date_format(date_create($note['notetime']),"H:i"));
		$f3->set('notetitle',$note['notetitle']);
		$f3->set('note',$note['note']);
		$f3->set('noteid',$noteid);
		$md = new Mooddb;
		$moodlist = $md->getMood();
		for($i=0;$i<count($moodlist);++$i){
			$moodlist[$i]["checked"] = "";
		}
		for($i=0;$i<count($note['moodtags']);++$i){
			for($j=0;$j<count($moodlist);++$j){
				if($note['moodtags'][$i]==$moodlist[$j]["description"]){
					$moodlist[$j]["checked"] = "checked";
					break;
				}
			}
		}
		$f3->set('datalist', $moodlist);
		echo template::instance()->render('modifynotes.html');
	}
);

//180313 add by lydia
$f3->route('POST /modifynote',
	function($f3){
		//make sure all required information is not null
		$success = true;
		$data = array();
		$data['noteid'] = $f3->get('POST.noteid');
		if(empty($data['noteid'])){
			$success = false;
		}
		if(empty($_SESSION['userinfo']['userid'])){
			$success = false;
		}
		$data['notetext'] = $f3->get('POST.note');
		$data['notetitle'] = $f3->get('POST.notetitle');
		$data['notedate'] = $f3->get('POST.notedate');
		$data['notetime'] = $f3->get('POST.notetime');
		$data['mood'] = $f3->get('POST.mood');
		$nc = new NoteController;
		$nc->modifyNote($data);
		if(success){
			//$f3->reroute('/'.$_SESSION['userinfo']['username'].'/home');
			$f3->reroute('/displaynotes');
		}
		
	}
);

//180313 add by lydia
$f3->route('POST /deletenote',
	function($f3){
		//make sure all required information is not null
		$success = true;
		$noteid = $f3->get('POST.noteid');
		if(empty($noteid)){
			$success = false;
		}
		if(empty($_SESSION['userinfo']['userid'])){
			$success = false;
		}
		$nc = new NoteController;
		$nc->deleteNote($noteid);
		if(success){
			//$f3->reroute('/'.$_SESSION['userinfo']['username'].'/home');
			$f3->reroute('/displaynotes');
		}
		
	}
);

//180316 add by lydia
$f3->route('POST /loadmore',
  function($f3){
	$postdata = json_decode($f3->get('POST.loadmore'),true);
	$moodtag = $postdata['moodtag'];
	$page = $postdata['page'];
	$md = new Mooddb();
	if($md->checkMood($moodtag)){
		echo "The mood entered does not exist, please choose a new one";
	}else{
		$fapi = new FlickrAPI;
		$request = $fapi->makingRequest($moodtag,$page);
		$items = $fapi->load($request);
		$link_list = $fapi->getingPictures($items);
		$is = new ImageServer();
		$uiurl = $f3->get('BASE')."/".$f3->get('UI');
		$constructed_html = null;
		//construct html
		for($i=0;$i<count($link_list);$i++){
			$mediaid = $is->checkLiked($link_list[$i]['img']);
			$key = $i+20*($page-1);
			$image_src = $f3->get('BASE')."/".$link_list[$i]['img_m'];
			$constructed_html_1 = $constructed_html.
							  "<div id=\"imgdisplay\" >".
							  "<p><a href=\"".$link_list[$i]['img']."\" id = \"img".$key."\" data-lightbox=\"image3\">".
							  "<img id = \"display\" src=\"".$image_src."\" class=\"mood_item photo\" /></a></p>";
			if(!empty($mediaid)){
				$constructed_html = $constructed_html_1.
							  "<p><button name = \"unlike\" id=\"button".$key."\" class = \"button_item photo heart transparent\" ".
							  "value=\"".$mediaid."\" onclick=\"passInf(".$key.",'".$f3->get('BASE')."','".$link_list[$i]['title']."','".
							  $link_list[$i]['url']."','".$f3->get('UI')."')\">".
							  "<img src=\""+$uiurl+"/images/heart2.svg\" height=\"35\" width=\"35\"/>".
							  "</button></p></div>";
			}else{
				$constructed_html = $constructed_html_1.
							  "<p><button name = \"like\" id=\"button".$key."\" class = \"button_item photo heart transparent\" ".
							  "value=\"".$mediaid."\" onclick=\"passInf(".$key.",'".$f3->get('BASE')."','".$link_list[$i]['title']."','".
							  $link_list[$i]['url']."','".$f3->get('UI')."')\">".
							  "<img src=\"".$uiurl."/images/heart1.svg\" height=\"35\" width=\"35\"/>".
							  "</button></p></div>";
			}
		}
		$result_html = $result_html.$constructed_html;
	}

	$result['result'] = true;
	$result['html'] = $result_html;
	
	echo json_encode($result);
  }
);

//180316 add by lydia
$f3->route('POST /predict',
  function($f3){
	$postdata = json_decode($f3->get('POST.predict'),true);
	$keyword = $postdata['str'];
	
	$Mdb = new Mooddb;
	$moodset = $Mdb->predict($keyword);

	foreach ($moodset as $item){
		$html = "<li onclick = \"addToSearchBar(this.innerHTML)\">".$item->description."</li>";
		$result = $result.$html;
	}
	echo json_encode($result);
  }
);
  ////////////////////////
 // Run the FFF engine //
////////////////////////

$f3->run();

?>

