<?php
// Class that provides methods for working with the images.  The constructor is empty, because
// initialisation isn't needed; in fact it probably never really needs to be instanced and all
// could be done with static methods.
//180310 lydia modify createThumbnail
//180310 lydia add upload via URL
//180313 lydia add get image and its thumbnail via mediaid
//180313 lydia add delete notes when delete image
class ImageServer {
	private $filedata;
	private $uploadResult = "Upload failed! (unknown reason) <a href=''>Return</a>";
	private $pictable = "recommendation";
	private $thumbsize_width = 200;			// max width/height of thumbnail images
	private $thumbsize_height = 175;			// max width/height of thumbnail images
// 	private $acceptedTypes = ["image/jpeg", "image/png", "image/gif", "image/tiff", "image/svg+xml"];
	private $acceptedTypes = ["image/jpeg", "image/png", "image/gif"];	// tiff and svg removed: image processing code can't handle them

	public function __construct() {}
	
	// abandoned experiment with a ::instance() method similar to the ones used elsewhere in F3
	// -- it works, but seems to have no advantages
	// 	public static function instance() {
	// 		return new self;
	// 	}

	// Puts the file data into the DB
	public function store() {
		global $f3;			// because we need f3->get()
		$mediatype = new DB\SQL\Mapper($f3->get('DB'),"mediatype");
		$moodtype = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		$mediatypeid = $mediatype->load(array('description=?',$this->filedata["type"]));
		$pic = new DB\SQL\Mapper($f3->get('DB'),$this->pictable);	// create DB query mapper object
		$pic->recomid = strtoupper(md5(uniqid(rand(),true)));
		$pic->title = $this->filedata["title"];
		$pic->url = $this->filedata["name"];
		$pic->mediatype = $this->filedata["type"];
		$pic->userid = $_SESSION['userinfo']['userid'];
		$pic->uploaddate = date("Ymd");
		$pic->uploadtime = date("H:i:s");
		$pic->urlsource = $this->filedata["urlsource"];
		
		$collections = new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		$collections->mediaid = strtoupper(md5(uniqid(rand(),true)));
		$collections->mediatype = $mediatypeid["typeid"];
		$collections->url = $this->filedata["name"];
		$collections->recommended = true;
		$collections->recomid = $pic->recomid;
		$collections->uploaddate =$pic->uploaddate;
		$collections->uploadtime =$pic->uploadtime; 
		$collections->title = $pic->title;
		
		$pic->save();
		$collections->save();
		
		$tags = new DB\SQL\Mapper($f3->get('DB'),"originalmoods");
		foreach ($this->filedata["moodtags"] as $record) {
			$tags->mediaid = $collections->mediaid;
			$moodtypeid = $moodtype->load(array('description=?',$record));
			$tags->moodtype = $moodtypeid['moodtypeid'];
			$tags->save();
			$tags->reset();
		}
	}

	// Upload file, using callback to get data, then copy data into local array.  
	// Call store() to store data, call createThumbnail(), add thumb name to the
	// array then return the array
	public function upload() {
		global $f3;		// so that we can call functions like $f3->set() from inside here

		$overwrite = false; // set to true, to overwrite an existing file; Default: false
		$slug = true; // rename file to filesystem-friendly version

		Web::instance()->receive(
			function($file,$anything){
				/* looks like:
				  array(5) {
					  ["name"] =>     string(19) "csshat_quittung.png"
					  ["type"] =>     string(9) "image/png"
					  ["tmp_name"] => string(14) "/tmp/php2YS85Q"
					  ["error"] =>    int(0)
					  ["size"] =>     int(172245)
					}
				*/
				// $file['name'] already contains the slugged name now

				$this->filedata = $file;		// export file data to outside this function
				// maybe you want to check the file size
				if($this->filedata['size'] > (2 * 1024 * 1024)) {		// if bigger than 2 MB
					$this->uploadResult = "Upload failed! (File > 2MB)  <a href=''>Return</a>";
					return false; // this file is not valid, return false will skip moving it
				}
				if(!in_array($this->filedata['type'], $this->acceptedTypes)) {		// if not an approved type 
					$this->uploadResult = "Upload failed! (File type not accepted)  <a href=''>Return</a>";
					return false; // this file is not valid, return false will skip moving it
				}
				// everything went fine, hurray!
				$this->uploadResult = "success";
				return true; // allows the file to be moved from php tmp dir to your defined upload dir
			},
			$overwrite,
			$slug
		);
	// 	var_dump($this->filedata);
 
 		if ($this->uploadResult != "success") {
 			echo $this->uploadResult;				// ideally this might be output from index.php
 			return null;
 		}
		
		$mood = $f3->get('POST.mood');
		if (empty($mood)){
			echo "Please select at least one mood tag <a href=''>Return</a>";
			return null;
		}

		$picname = $f3->get('POST.picname');
		$this->filedata["title"] = $picname;		// add the title to filedata for later use
		$this->filedata["moodtags"] = $mood;
		$this->store();
		$this->createThumbnail($this->filedata["name"], $f3->get("UPLOADS") . "/thumb/" .$this->thumbFile($this->filedata["name"]), basename($this->filedata["type"]));
		$this->filedata["thumbNail"] = $this->thumbFile($this->filedata["name"]);		// add the thumbnail to filedata for later use

		return $this->filedata;
	}


	// This just returns all the data we have about images in the DB, just as an array.
	// If given no argument, it uses the default argument, 0, and in this case it returns data about all images.
	// If given an image ID as argument (there can be no image with ID 0), it returns data only about that image.
	public function getUpload($picID=0) {
		global $f3;
		$returnData = array();
		$pic=new DB\SQL\Mapper($f3->get('DB'),$this->pictable);	// create DB query mapper object
		$recommendinfo = new DB\SQL\Mapper($f3->get('DB'),"recommendinfo");
		//$list = $pic->find(array('userid=? AND valid=?',$_SESSION['userinfo']['userid'],true)); //160326 mark by lydia
		$list = $pic->find(array('userid=? AND valid=? AND mediatype IN ("image/jpeg","image/png","image/gif")',$_SESSION['userinfo']['userid'],true)); //160326 add by lydia
		if ($picID == 0) {
			foreach ($list as $record) {
				$recordData = array();
				$tags_list = array();
				$tags = array();
				$recordData["title"] = $record["title"];
				$recordData["mediatype"] = $record["mediatype"];
				$recordData["url"] = $record["url"];
				$recordData["recomid"] = $record["recomid"];
				$recordData["thumbNail"] = $f3->get('UPLOADS'). "/thumb/" .$this->thumbFile($record["url"]);
				$tags_list = $recommendinfo->find(array("recomid=?",$record["recomid"]));
				$recordData["mediaid"] = $tags_list[0]["mediaid"];//180312 add by lydia
				foreach($tags_list as $moodtag){
					array_push($tags,$moodtag["description"]);
				}
				$recordData["tags"] = $tags;
				array_push(	$returnData, $recordData);
			}
			return $returnData;
		}
		$pic->load(array('recomid=? AND userid=? AND valid=?',$picID,$_SESSION['userinfo']['userid'],true));
		$recordData = array();
		$tags_list = array();
		$tags = array();
		$recordData["title"] = $pic["title"];
		$recordData["mediatype"] = $pic["mediatype"];
		$recordData["url"] = $pic["url"];
		$recordData["recomid"] = $pic["recomid"];
		$tags_list = $recommendinfo->find(array("recomid=?",$recordData["recomid"]));
		$recordData["mediaid"] = $tags_list[0]["mediaid"]; //180312 add by lydia
		foreach($tags_list as $moodtag){
			array_push($tags,$moodtag["description"]);
		}
		$recordData["tags"] = $tags;
		return $recordData;
	}
	
	public function getLiked($picID=0) {
		global $f3;
		$returnData = array();
		$likedpic=new DB\SQL\Mapper($f3->get('DB'),"userandmedia");	// create DB query mapper object
		$moodtags = new DB\SQL\Mapper($f3->get('DB'),"personalmood");
		$moodtype = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		if ($picID == 0) {
			$data_list = $likedpic->find(array('userid=? AND mediatype IN ("1","2","3")',$_SESSION['userinfo']['userid']));
			foreach ($data_list as $record) {
				$recordData = array();
				$tags_list = array();
				$tags=array();
				$recordData["title"] = $record["title"];
				$recordData["mediatype"] = $record["mediatype"];
				$recordData["img"] = $record["url"];
				$recordData["url"] = $record["mediasource"];
				$recordData["mediaid"] = $record["mediaid"];
				$suffix = substr(strrchr($recordData["img"], '.'), 1);
				$path = pathinfo($recordData["img"]);
				//$recordData["img_m"] = $path['dirname']."/".basename($recordData["img"],".".$suffix)."_m.".$suffix;
				$fapi = new FlickrAPI();
				$thumb = $fapi->createThumbnail([$recordData["img"]]);
				$recordData["img_m"] = $thumb[0];
				$tags_list = $moodtags->find(array("userid=? AND mediaid=?",$_SESSION['userinfo']['userid'],$record['mediaid']));
				foreach($tags_list as $moodtag){
					$moodtype->load(array('moodtypeid=?',$moodtag["mood"]));
					array_push($tags,$moodtype["description"]);
				}
				$recordData["tags"] = $tags;
				array_push(	$returnData, $recordData);
			}
			return $returnData;
		}
		$likedpic->load(array('mediaid=? AND userid=?',$picID,$_SESSION['userinfo']['userid']));
		$recordData = array();
		$tags_list = array();
		$tags = array();
		$recordData["title"] = $likedpic["title"];
		$recordData["mediatype"] = $likedpic["mediatype"];
		$recordData["img"] = $record["url"];
		$recordData["url"] = $record["mediasource"];
		$recordData["mediaid"] = $record["mediaid"];
		$suffix = substr(strrchr($recordData["img"], '.'), 1);
		//$recordData["img_m"] = basename($recordData["img"],".".$suffix)."_m.".$suffix;
		$fapi = new FlickrAPI();
		$recordData["img_m"] = $fapi->createThumbnail($recordData["img"]);
		$tags_list = $moodtags->find(array("userid=? AND mediaid=?",$_SESSION['userinfo']['userid'],$record['mediaid']));
		foreach($tags_list as $moodtag){
			$moodtype->load(array('moodtypeid=?',$moodtag["mood"]));
			array_push($tags,$moodtype["description"]);
		}
		$recordData["tags"] = $tags;
		return $recordData;
	}

	// Delete data record about the image, and remove its file and thumbnail file
	public function deleteService($recomID) {
		global $f3;
		$pic=new DB\SQL\Mapper($f3->get('DB'),$this->pictable);	// create DB query mapper object
		$collections = new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		$tags = new DB\SQL\Mapper($f3->get('DB'),"originalmoods");
		$notemapper = new DB\SQL\Mapper($f3->get('DB'),"notes"); //180313 add by lydia
		$pic->load(['recomid=?',$recomID]);							// load DB record matching the given ID
		unlink($pic["url"]);										// remove the image file
		unlink($f3->get('UPLOADS')."/thumb/".$this->thumbFile($pic["url"]));	// remove the thumbnail file
		$collections->load(['recomid=?',$recomID]);
		if($collections->count>1){
			$pic->url = $f3->get("UPLOADS")."404.jpg";
			$pic->valid = false;
			$pic->save();
			$collections->url = $f3->get("UPLOADS")."404.jpg";
			$collections->save();
			/*180313 add by lydia start: delete the notes of this user*/
			$noteset = $notemapper->find(array('mediaid=? AND userid=?',$collections->mediaid,$_SESSION['userinfo']['userid']));
			$nc = new NoteController;
			foreach($noteset as $note){
				$nc->deleteNote($note->noteid);
			}
			/*180313 add by lydia end*/
		}else{
			$tags->load(array('mediaid=?',$collections['mediaid']));
			while(!$tags->dry()){
				$tags->erase();
				$tags->next();
			}
			/*180313 add by lydia start: delete the notes of this user*/
			$noteset = $notemapper->find(array('mediaid=? AND userid=?',$collections->mediaid,$_SESSION['userinfo']['userid']));
			$nc = new NoteController;
			foreach($noteset as $note){
				$nc->deleteNote($note->noteid);
			}
			/*180313 add by lydia end*/
			$collections->erase();
			$pic->url = $f3->get("UPLOADS")."404.jpg";
			$pic->valid = false;
			$pic->save();
		}
	}

	public function unlike($mediaid) {
		global $f3;
		$mediacollections = new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		$collections = new DB\SQL\Mapper($f3->get('DB'),"collections");
		$personaltags = new DB\SQL\Mapper($f3->get('DB'),"personalmood");
		$notemapper = new DB\SQL\Mapper($f3->get('DB'),"notes"); //180313 add by lydia
		$mediacollections->load(['mediaid=?',$mediaid]);							// load DB record matching the given ID	
		$collections->load(array('mediaid=? AND userid =?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
		$personaltags->load(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
		while(!$personaltags->dry()){
			$personaltags->erase();
			$personaltags->next();
		}
		$collections->erase();
		if($mediacollections->count>1){
			$mediacollections->count--;
			$mediacollections->save();
			/*180313 add by lydia start: delete the notes of this user*/
			$noteset = $notemapper->find(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
			$nc = new NoteController;
			foreach($noteset as $note){
				$nc->deleteNote($note->noteid);
			}
			/*180313 add by lydia end*/
		}else{
			$originalmoods = new DB\SQL\Mapper($f3->get('DB'),"originalmoods");
			$originalmoods->load(array('mediaid=?',$mediacollections->mediaid));
			while(!$originalmoods->dry()){
				$originalmoods->erase();
				$originalmoods->next();
			}
			/*180313 add by lydia start: delete the notes of this user*/
			$noteset = $notemapper->find(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']));
			$nc = new NoteController;
			foreach($noteset as $note){
				$nc->deleteNote($note->noteid);
			}
			/*180313 add by lydia end*/
			$mediacollections->erase();
		}
	}

	// A method that finds the file for a given image ID, and ouputs the raw content of it with a 
	// suitable header, e.g. so that <img src="/image/ID" /> will work.
	// This is necessary because image files are stored above the web root, so have no direct URL.
	/*public function showImage($picID, $thumb) {
		global $f3;
		$pic=new DB\SQL\Mapper($f3->get('DB'),$this->pictable);	// create DB query mapper object
		$pic->load(['id=?',$picID]);							// load DB record matching the given ID
		$fileToShow = ($thumb?$f3->get('UPLOADS').$this->thumbFile($pic["picfile"]):$pic["picfile"]);
		$fileType = ($thumb?"image/jpeg":$pic["pictype"]);		// thumb is always jpeg
		header("Content-type: " . $fileType);		// write out the image file http header
		readfile($fileToShow);						// write out raw file contents (image data)
	}*/
	
	
	// Create the name of the thumbnail file for the given image file
	// -- just by adding "thumb-" to the start, but bearing in mind that it
	// will always be a .jpg file.
	public function thumbFile($picfile) { //180312 modify by lydia private->public
			return "thumb-".pathinfo($picfile,PATHINFO_FILENAME).".jpg";
	}
	
	// This creates the actual thumbnail by resampling the image file to the size given by the thumbsize variable.
	// We can easily change this.  PHP has very rich image processing functionality; this is a simple example.
    // Based on code from PHP manual for imagecopyresampled()
    // NB this is old code: most of these functions also have F3 wrappers, which might be neater here ...
	private function createThumbnail($filename, $thumbfile, $type) {
	  // Set a maximum height and width
	  $width = 0;
	  $height = 0;
	  $thumbsize_width = $this->thumbsize_width;
	  $thumbsize_height = $this->thumbsize_height;
	  $x_start = 0;
	  $y_start = 0;
	  
	  // Get new dimensions
	  list($width_orig, $height_orig) = getimagesize($filename);
	  
	  /*$ratio_orig = $width_orig/$height_orig;
	  
	  if ($width/$height > $ratio_orig) {
		 $width = $height*$ratio_orig;
	  } else {
		 $height = $width/$ratio_orig;
	  }*/
	  
	  //180310 add by lydia
      if(($width_orig/$height_orig)>($thumbsize_width/$thumbsize_height)){
			$height = $thumbsize_height;
			$width = $width_orig*($height/$height_orig);
	  }else{
			$width = $thumbsize_width;
			$height = $height_orig*($width/$width_orig);
	  }
	  
	  /* 180310 mark by lydia
	  if($width_orig<2*$width){
		  $x_start=0;
	  }else{
		  $x_start = $width_orig-$width;
	  }
	  if($height_orig<2*$height){
		  $y_start = 0;
	  }else{
		  $y_start = $height_orig-$height;
	  }*/
	  
	  
	  // Resample
	  $image_p = imagecreatetruecolor($width, $height);
	  switch ($type) {
		  case "jpeg":
		  	$image = imagecreatefromjpeg($filename);
		  	break;
		  case "png":
		  	$image = imagecreatefrompng($filename);
		  	break;
		  case "gif":
		  	$image = imagecreatefromgif($filename);
		  	break;
		  default:
		  	$data = file_get_contents($filename);
		  	$image = imagecreatefromstring($data);
	  }
	  imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
	  $image_thumb = $this->imagecrop($image_p, ['x' => x_start, 'y' => y_start, 'width' => $thumbsize_width, 'height' => $thumbsize_height]);
	  // Output
	  // Notice this is always a jpeg image.  We could also have made others, but this seems OK.
	  //imagejpeg($image_p, $thumbfile);
	  imagejpeg($image_thumb, $thumbfile);
	}
	
	public function addFavorite($image){
		global $f3;
		$mediacollections=new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		$collections = new DB\SQL\Mapper($f3->get('DB'),"collections");
		$predefined = new DB\SQL\Mapper($f3->get('DB'),"originalmoods");
		$personaldefined = new DB\SQL\Mapper($f3->get('DB'),"personalmood");
		$mediatype = new DB\SQL\Mapper($f3->get('DB'),"mediatype");
		$moodtype = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		$moodid = $moodtype->load(array('description=?',$image['moodtag']));
		$mediaid = NULL;
		if($this->checkURL($image['img'])){
			$mediacollections->load(array('url=?',$image['img']));
			$mediaid = $mediacollections->mediaid;
			if($collections->count(array('mediaid=? AND userid=?',$mediacollections->mediaid,$_SESSION['userinfo']['userid']))>0){
				if($personaldefined->count(array('userid=? AND mediaid=? AND mood=?',$_SESSION['userinfo']['userid'],$mediacollections->mediaid,$moodid['moodtypeid']))==0){
					$predefined->mediaid = $mediacollections->mediaid;
					$predefined->moodtype = $moodid['moodtypeid'];
					$personaldefined->save();
				}
			}else{
				$collections->userid = $_SESSION['userinfo']['userid'];
				$collections->mediaid = $mediacollections->mediaid;
				$collections->uploaddate = date('Ymd');
				$collections->uploadtime = date("H:i:s");
				$collections->save();
				$mediacollections->count++;
				$mediacollections->save();
			}
			if($predefined->count(array('mediaid=? AND moodtype=?',$mediacollections->mediaid,$moodid['moodtypeid']))==0){
				$predefined->mediaid = $mediacollections->mediaid;
				$predefined->moodtype = $moodid['moodtypeid'];
				$predefined->save();
			}

		}else{
			$mediacollections->mediaid = strtoupper(md5(uniqid(rand(),true)));
			$mediaid = $mediacollections->mediaid;
			$mediatypeid = $mediatype->load(array('description=?',"image/jpeg"));
			$mediacollections->mediatype = $mediatypeid['typeid'];
			$mediacollections->url = $image['img'];
			$mediacollections->recommended = false;
			$mediacollections->uploaddate = date('Ymd');
			$mediacollections->uploadtime = date("H:i:s");
			$mediacollections->mediasource = $image['url'];
			$mediacollections->title = $image['title'];
			
			$collections->userid = $_SESSION['userinfo']['userid'];
			$collections->mediaid = $mediacollections->mediaid;
			$collections->uploaddate = $mediacollections->uploaddate;
			$collections->uploadtime = $mediacollections->uploadtime;
			
			$predefined->mediaid = $mediacollections->mediaid;
			$predefined->moodtype = $moodid['moodtypeid'];
			
			$personaldefined->userid = $collections->userid;
			$personaldefined->mediaid = $collections->mediaid;
			$personaldefined->mood = $predefined->moodtype;
			
			$mediacollections->save();
			$collections->save();
			$predefined->save();
			$personaldefined->save();
		}
		return $mediaid;
	}
	
	public function checkURL($url){
		global $f3;
		$mediacollections=new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		if($mediacollections->count(array('url=?',$url))==0){
			return 0;
		}else{
			return 1;
		}
	}
	
	
	public function checkLiked($img){
		global $f3;
		$userandmedia=new DB\SQL\Mapper($f3->get('DB'),"userandmedia");
		$userandmedia->load(array('url=? AND userid=?',$img,$_SESSION['userinfo']['userid']));
		if($userandmedia->dry()){
			return ;
		}else{
			return $userandmedia->mediaid;
		}
	}
	
	function imagecrop($image, array $rect)
	{
		$result = imagecreatetruecolor($rect['width'], $rect['height']);
		imagecopy(
			$result,
			$image,
			0,
			0,
			(int)$rect['x'],
			(int)$rect['y'],
			(int)$rect['width'],
			(int)$rect['height']
		);
		return $result;
	}
	
	//180310 add by lydia
	function uploadurl($imageinfo){
		global $f3;
		$this->filedata = array();
		$this->filedata['urlsource'] = $imageinfo['url'];
		$this->filedata['title'] = $imageinfo['picname'];
		$this->filedata['moodtags'] = $imageinfo['moodtags'];
		$result = Web::instance()->request($imageinfo['url']);
		/* returns:

		array(4) {
			'body' => string " IMAGE BINARY DATA " (length=7761)
			'headers' =>
				array (size=16)
				0 => string 'HTTP/1.1 200 OK' (length=15)
				1 => string 'Accept-Ranges: bytes' (length=20)
				2 => string 'access-control-allow-origin:*' (length=30)
				3 => string 'access-control-expose-headers: Content-Length' (length=45)
				4 => string 'Cache-Control: max-age=2678400' (length=30)
				5 => string 'Content-Type: image/jpeg' (length=24)
				6 => string 'Date: Thu, 18 Dec 2013 12:40:11 GMT' (length=35)
				7 => string 'Last-Modified: Fri, 22 Mar 2013 09:41:02 GMT' (length=44)
				8 => string 'Server: nginx' (length=13)
				9 => string 'surrogate-key: media media/bucket/3 media/971762472326590465' (length=60)
				10 => string 'X-Cache: HIT' (length=12)
				11 => string 'x-connection-hash' (length=51)
				12 => string 'x-content-type-options:nosniff' (length=31)
				13 => string 'x-response-time:123' (length=20)
				14 => string 'Content-Length: 7761' (length=20)
				15 => string 'Connection: close' (length=17)
			'engine' => string 'cURL' (length=4)
			'cached' => boolean false
			'error' => string '' (length=0)
		}
		*/
		if(!empty($result['error'])){
			return [false,$result['error']];
		}
		$path = $f3->get('UPLOADS').date('Ymd').date('His').rand();
		for($i=0;$i<count($result['headers']);++$i){
			$category = explode(':',$result['headers'][$i]);
			if(trim($category[0]) == "Content-Type"){
				$this->filedata['type'] = trim($category[1]);
			}
		}
		//$type = explode(':',$result['headers'][5]);
		$content = imagecreatefromstring($result['body']);
		switch ($type) {
			case "image/jpeg":
				$path = $path.".jpg";
				imagejpeg($content,$path);
				break;
			case "image/png":
				$path = $path.".png";
				imagepng($content,$path);
				break;
			case "image/gif":
				$path = $path.".gif";
				imagegif($content,$path);
				break;
			default:
				$path = $path.".jpg";
				imagejpeg($content,$path);
				break;
		}
		$this->filedata['name'] = $path;
		$this->createThumbnail($this->filedata["name"], $f3->get("UPLOADS") . "/thumb/" .$this->thumbFile($this->filedata["name"]), basename($this->filedata["type"]));
		$this->store();
		return [true,""];
	}
	
	//180313 add by lydia
	public function getImageViaMediaid($mediaid){
		global $f3;
		$result = array();
		$fapi = new FlickrAPI;
		$mediacollections=new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		$target = $mediacollections->load(array('mediaid=?',$mediaid));
		if(!empty($target->recomid)){ //user upload
			$result['img'] = $f3->get("BASE")."/".$target->url;
			$result['thumbnail'] = $f3->get('UPLOADS'). "/thumb/" .$this->thumbFile($target->url);
		}else{ //user liked
			$result["img"] = $target->url;
			$thumb = $fapi->createThumbnail([$result["img"]]);
			$result["thumbnail"] = $thumb[0];
		}
		return $result;
	}
}
?>
