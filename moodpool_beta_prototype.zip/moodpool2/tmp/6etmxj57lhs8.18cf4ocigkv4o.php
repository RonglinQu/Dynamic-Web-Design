<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<!-- Bootstrap -->
<!-- <link href="<?= ($BASE) ?>/<?= ($UI) ?>css/bootstrap.min.css" rel="stylesheet"> -->
<!-- <link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/flatly/bootstrap.min.css" rel="stylesheet"> -->
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- style MODAL 2-->	
<link href="<?= ($BASE) ?>/<?= ($UI) ?>/css/lightbox.css" rel="stylesheet" type="text/css">
<!-- Stylesheet CSS-->	
<link href="<?= ($BASE) ?>/<?= ($UI) ?>css/filtertest_style.css" rel="stylesheet">	
<!-- <link rel="stylesheet" href="<?= ($BASE) ?>/<?= ($UI) ?>/css/main.css" type="text/css"> -->
<!-- JavaScripts -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
<script src="<?= ($BASE) ?>/<?= ($UI) ?>js/prueba.js"></script>
<!-- 180221 add by lydia -->
<script src="<?= ($BASE) ?>/<?= ($UI) ?>js/searchresult.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- JavaScripts POPOUT -->
<!-- JavaScripts MODAL 2-->	
<script type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>/js/lightbox.min.js"></script>

<!-- 180329 added by Ronglin  -->
<link rel="stylesheet" href="<?= ($BASE) ?>/<?= ($UI) ?>/css/music.css" media="screen" type="text/css" />


<body>
<div id="wrapper">	 
<!--LOGO--> 	
<div class="col-md-12">	
	<div class="row"> 
		<div class="col-md-12 dropdown-padding">
	<!--Mood Selector--> 	   
		  Select a mood:
		  <div class="btn-group">
			  <button type="button" class="btn dropdown-toggle moodselector-style" data-toggle="dropdown">
				<b id = "moodtag"><?= ($mood) ?></b> <span class="caret"></span>
			  </button> 
			  <ul class="dropdown-menu" id = "dropdown_ul">
				<!--<li><a href="#">Relaxed</a></li>
				<li><a href="#">Joy</a></li>
				<li><a href="#">Melancholy</a></li>
				<li><a href="#">Gloomy</a></li> -->
				<?php foreach (($moodlist?:[]) as $mooddetail): ?>
					<li><a href="<?= ($BASE) ?>/search/<?= ($mooddetail['description']) ?>"><?= ($mooddetail['description']) ?></a></li>
				<?php endforeach; ?>
			  </ul>
		  </div>
		</div>
	<!--User image Btn-->		
	</div>   
</div>	

<div class="col-md-12">
<div class="row"> 	
<div class="category-continer">
	<p class="category_item item_style" id="all">All Media </p>
	<p class="category_item item_style" id="photo">Photos</p>
	<p class="category_item item_style" id="video">Videos</p>
	<p class="category_item item_style" id="music">Music</p>
	<p class="category_item item_style" id="illustration">Illustration</p>
	<p class="category_item item_style" id="article">Articles</p>
	<p class="category_item item_style" id="book">Books</p>
</div>
</div>
</div>
	
<div class="col-md-12">
<div class="row">
<div class="block_container">
<!-- Ejemplo popout -->
	<?php foreach (($searchresult?:[]) as $ikey=>$item): ?>
		<!-- 180327 Added by Ronglin -->
	  <!-- change the original class="mood_item" into class="allmediatags" -->
	  <!-- 180328 added by Ronglin   add the class of img -->
	  <!-- 180329 added by Ronglin   delete the tags' words -->
    <div id="imgdisplay" >
			<p><a href="<?= ($item['img']) ?>" id = "img<?= ($ikey) ?>" data-lightbox="image3"><img id = "display" src="<?= ($BASE) ?>/<?= ($item['img_m']) ?>" class="allmediatags photo" /></a></p>
			<!-- <p><a href="<?= ($item['url']) ?>" id = "url<?= ($ikey) ?>">link</a></p> -->
			<!-- <p id = "hidtitle<?= ($ikey) ?>"><i id="title<?= ($ikey) ?>"><?= ($item['title']) ?></i></p> -->
			<p><button name = "" id="button<?= ($ikey) ?>" class = "button_item photo heart transparent" value="<?= ($item['mediaid']) ?>" onclick="passInf(<?= ($ikey) ?>,'<?= ($BASE) ?>','<?= ($item['title']) ?>','<?= ($item['url']) ?>','<?= ($UI) ?>')"><?= ($item['liked']) ?></button></p>
			<script type="text/javascript">
				liked(<?= ($ikey) ?>,"<?= ($BASE) ?>/<?= ($UI) ?>");
			</script>
			<!--<p class="typetags mood_item photo">Photos</p>-->
			<div class="typetags button_item photo">
				<img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/phototag.svg" alt="" width="20px" height="20px" style="vertical-align:middle; padding-right:3px">
			</div>
		</div>
	<?php endforeach; ?>
	<?php foreach (($musicdataset?:[]) as $musickey=>$musicitem): ?>
		<div id="musicdisplay" >
			<img id = "musicdisplay<?= ($musickey) ?>" src="<?= ($musicitem['img']) ?>" class="allmediatags music md-trigger" onerror="this.src='<?= ($BASE) ?>/data/image/thumb/NoCover.png'" width="175" height="213" data-modal="modal-1" onclick="pop('<?= ($musicitem['url']) ?>','<?= ($musicitem['title']) ?>','<?= ($musicitem['artist']) ?>','<?= ($musicitem['album']) ?>','<?= ($musicitem['img']) ?>')"/>
			<p><button name = "" id="musicbutton<?= ($musickey) ?>" class = "button_item music heart transparent" value="<?= ($musicitem['mediaid']) ?>" onclick="musicpassInf(<?= ($musickey) ?>,'<?= ($BASE) ?>','<?= ($musicitem['title']) ?>','<?= ($UI) ?>','<?= ($musicitem['url']) ?>','<?= ($musicitem['artist']) ?>')"><?= ($musicitem['liked']) ?></button></p>
			<script type="text/javascript">
				musicliked(<?= ($musickey) ?>,"<?= ($BASE) ?>/<?= ($UI) ?>");
			</script>
			<div class="typetags button_item music">
				<img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/musictag.svg" alt="" width="20px" height="20px" style="vertical-align:middle; padding-right:3px">
			</div>
		</div>
	<?php endforeach; ?>
	<!-- <img src="http://via.placeholder.com/200x175" class="mood_item photo"> -->
<!-- after class add the especific tag for the media -->
	<!-- <img src="http://via.placeholder.com/200x175" class="mood_item photo">
	<img src="http://via.placeholder.com/200x175" class="mood_item video">
	<img src="http://via.placeholder.com/200x175" class="mood_item photo">
	<img src="http://via.placeholder.com/200x175" class="mood_item video">
	<img src="http://via.placeholder.com/200x175" class="mood_item music">
	<img src="http://via.placeholder.com/200x175" class="mood_item book">
	<img src="http://via.placeholder.com/200x175" class="mood_item photo">
	<img src="http://via.placeholder.com/200x175" class="mood_item music">
	<img src="http://via.placeholder.com/200x175" class="mood_item photo">
	<img src="http://via.placeholder.com/200x175" class="mood_item book">
	<img src="http://via.placeholder.com/200x175" class="mood_item article">
	<img src="http://via.placeholder.com/200x175" class="mood_item music">
	<img src="http://via.placeholder.com/200x175" class="mood_item illustration">
	<img src="http://via.placeholder.com/200x175" class="mood_item video">
	<img src="http://via.placeholder.com/200x175" class="mood_item illustration">
	<img src="http://via.placeholder.com/200x175" class="mood_item music">
	<img src="http://via.placeholder.com/200x175" class="mood_item video">
	<img src="http://via.placeholder.com/200x175" class="mood_item photo">
	<img src="http://via.placeholder.com/200x175" class="mood_item music">
	<img src="http://via.placeholder.com/200x175" class="mood_item illustration">
	<img src="http://via.placeholder.com/200x175" class="mood_item book">
	<img src="http://via.placeholder.com/200x175" class="mood_item article"> -->
	
</div>
</div>
</div>
<!-- POPOUT -->		
	
<!-- POPOUT -->	
<!--<div><button onclick="loadmore('<?= ($BASE) ?>','<?= ($mood) ?>')">Load More<button></div>-->
<!--newly added for load more button-->	<!--180328 add start -->
<div class="row">
	<div class="loadmore" id = "loadmore">
		<a onclick="loadmore('<?= ($BASE) ?>','<?= ($mood) ?>')" class="loadmore-btn" role="button"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/icon-plus.png"> </a>
	</div>	
</div>
<!--180328 add end -->
</div>
<!-- 180328 added by Ronglin  -->
<div class="wholemusic">

</div>

	<div class="md-modal md-effect-1" id="modal-1">

		<div class="cardleft">
			<div> <!--Main image -->

				<div class="canvas" id="album_cover" style="background-image: url('')"></div>
				<!-- tags -->
				<div class="rqtags_list">
					<ul>
						<li class="rqtags_content">
							<div class="rqtags_words"><?= ($mood) ?></div>
						</li>
						<!-- <li class="rqtags_content">
							<div class="rqtags_words">Melancholy</div>
						</li>
						<li class="rqtags_content">
							<div class="rqtags_words">Sad</div>
						</li> -->
						
					</ul>
				</div>

			</div>

			<!-- <hr> -->
			<div class="card">

				 <!-- waves -->
				 <div class="inner"></div>
				 <div class="inner"></div>
				 <div class="inner"></div>

				<div class="music">
					<div class="musicbtn">
						<img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/album.png" alt="" width="25px" height="25px" style="vertical-align:middle">
						<span style="margin-left:5px">Music</span>
					</div>

					<div class='musicinfo'>

						<p class="title" id="track_title">Orion</p>
						<!-- title -->

						<div class="artist" style="vertical-align:middle">
							<span style="font-style: italic">by</span>
							<span style="font-size:24px; font-weight:bold; margin-left:10px" id="track_artist">Kenshi Yonezu</span>
						</div>
						<!-- artist -->

						<div class="album" style="vertical-align:middle">
							<span style="font-style:italic">album</span>
							<span style="font-size: 24px; font-weight: bold; margin-left:10px" id="album_title">Bootleg</span>
						</div>  <!-- ALBUM -->
					</div>
					<!-- musicinfo -->
				</div>

  			<form id="track_link" action="" method="get">
				<button class="musicplay">Play Music</button>
			</form>
			<span class="md-close exit"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/x-mark-gray.png" alt="" width='20px' height='20px'></span>
		</div> <!-- card -->

</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->
<!-- 180329 added by Ronglin  -->
<script>
	// this is important for IEs
	var polyfilter_scriptpath = '/js/';
</script>
<script src="<?= ($BASE) ?>/<?= ($UI) ?>/js/index.js"></script>
	
</body>
</html>
