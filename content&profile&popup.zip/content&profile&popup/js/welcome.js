function userhidden(user,login,logout){
	document.getElementById('user').style.visibility = user;
	document.getElementById('login').style.visibility = login;
	document.getElementById('logout').style.visibility = logout;
}
