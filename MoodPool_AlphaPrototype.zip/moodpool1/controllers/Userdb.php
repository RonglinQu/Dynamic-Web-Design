<?php
// Class that provides methods for working with the form data.
// There should be NOTHING in this file except this class definition.
// this php is modified from simpleController.php in SimpleExample app

class Userdb {
	private $mapper;
	
	public function __construct() {
		global $f3;						// needed for $f3->get() 
		$this->mapper = new DB\SQL\Mapper($f3->get('DB'),"users");	// create DB query mapper object
																			// for the "users" table
	}
	
	public function putIntoDatabase($data) {
		if ($this->mapper->count(array('username=?',$data["username"]))){
			return 1;
		}
		if ($this->mapper->count(array('email=?',$data["email"]))){
			return 2;
		}
		$this->mapper->username = $data["username"];					// set value for "name" field
		$this->mapper->password = md5($data["password"]);				// set value for "password" field
		$this->mapper->email = $data["email"];
		$this->mapper->save();		// save new record with these fields
		return 0;
	}
	
	public function checkUserInfo($data) {
		if(strpos($data["usernameemail"],'@')!= false){
			$email = $data["usernameemail"];
			if (!$this->mapper->count(array('email=?',$email))){
				return 1;
			}else if (!$this->mapper->count(array('email=? AND password=?',$email,md5($data["password"])))){
				return 2;
			}
		}else{
			$username = $data["usernameemail"];
			if (!$this->mapper->count(array('username=?',$username))){
				return 1;
			}else if (!$this->mapper->count(array('username=? AND password=?',$username,md5($data["password"])))){
				return 2;
			}
		}
		return 0;
	}
	public function getData() {
		$list = $this->mapper->find();
		return $list;
	}
	
	public function deleteFromDatabase($idToDelete) {
		$this->mapper->load(['id=?', $idToDelete]);				// load DB record matching the given ID
		$this->mapper->erase();									// delete the DB record
	}
	
	public function getUserId($username){
	    $id = $this->mapper->load(['username=?',$username]);
		return $id['userid']; 
	}
	
	public function checkUserName($username){
	    if(strpos($username,'@')!= false){
			return false;
		}else{
			return true; 
		}
	}
	
	public function checkUserEmail($email){
	    if(strpos($email,'@')!= false){
			return true;
		}else{
			return false; 
		}
	}
	
	public function getUserInfo($data){
		if(strpos($data,'@')!= false){
			$info = $this->mapper->load(['email=?',$data]);
		}else{
			$info = $this->mapper->load(['username=?',$data]);
		}
		$return_data['userid'] = $info['userid'];
		$return_data['username'] = $info['username'];
		$return_data['email'] = $info['email'];
		return $return_data; 
	}
}

?>
