<!doctype html>
<html>
<head>	
<title>show image</title>	
</head>
<body> 	
<img src="<?= ($imageurl) ?>" />
<form>
	<input type = "text" name = "note" />
</form>
</body>
</html>
