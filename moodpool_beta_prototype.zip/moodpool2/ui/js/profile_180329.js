$(function() {
  $(".limit1:checkbox").click(function() {
    var checked = $(".limit1:checkbox:checked");
    if (checked.length >= 4) {
		alert("no more than 3 tags");
		$(this).attr('checked', false);
    }

  });
});	
$(function() {
  $(".limit2:checkbox").click(function() {
    var checked = $(".limit2:checkbox:checked");
    if (checked.length >= 4) {
		alert("no more than 3 tags");
		$(this).attr('checked', false);
    }

  });
});	