var base_path = '/~s1734032/moodpool2';

$(function(){
	$("#form_login").submit(function(event){
		event.preventDefault();
		var usernameemail = document.getElementById("usernameemail").value;
		var pwd = document.getElementById("password").value;
		var data = JSON.stringify({ usernameemail: usernameemail,pwd:pwd});
		var path = base_path.concat('/login');
		$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { dataset : data }, 
				datatype: 'json',
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res['result']){
						var redirect = base_path.concat(res['redirect']);
						window.location.href = redirect;
					}else{
						$(".displayerror_login").show();
						document.getElementById("errormessage_login").innerHTML = res['error'];
						document.getElementById("usernameemail").value = '';
						document.getElementById("password").value = '';
					}
				}
			}
		);
	});
});

$(document).ready(function(){
	$(".displayerror_login").hide();
});

function displayerror(){
	$(".displayerror_login").show();
	document.getElementById("errormessage_login").innerHTML = 'fields cannot be empty';
}

$('.fliper-btn').click(function(){
    $('.flip').find('.card').toggleClass('flipped');

});// JavaScript Document
