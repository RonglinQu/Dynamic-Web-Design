<!doctype html>
<html>
	<head>	
		<title>show notes</title>	
	</head>
	<body>
		<?php foreach (($datalist?:[]) as $note): ?>
			<a href="<?= ($note['img']) ?>"><img src="<?= ($note['thumbnail']) ?>" /></a>
			<form action = "<?= ($BASE) ?>/createnote" method = "get">
				<button type = "submit" name="mediaid" value="<?= ($note['mediaid']) ?>">create</button>
			</form>
			<?php foreach (($note['noteset']?:[]) as $notedetail): ?>
				<p>title:<?= ($notedetail['notetitle']) ?></p>
				<p>date:<?= ($notedetail['notedate']) ?></p>
				<p>time:<?= ($notedetail['notetime']) ?></p>
				<p>note:<?= ($notedetail['note']) ?></p>
				mood:
				<?php foreach (($notedetail['moodtags']?:[]) as $moodtype): ?>
					<label><?= ($moodtype) ?></label>
				<?php endforeach; ?>
				<p/>
				<form action = "<?= ($BASE) ?>/modifynote" method = "get">
					<button type = "submit" name="noteid" value="<?= ($notedetail['noteid']) ?>">modify</button>
				</form>
				<p/>
				<form action = "<?= ($BASE) ?>/deletenote" method = "post">
					<button type = "submit" name="noteid" value="<?= ($notedetail['noteid']) ?>">delete</button>
				</form>
				<hr>
			<?php endforeach; ?>
		<?php endforeach; ?>
	</body>
</html>
