var targetMediaid = null;
var moods;
var base_path_global = null;
var noteid = null;
var title_bp;
var date_bp;
var note_bp;

$(function() {
  $(".limit1:checkbox").click(function() {
    var checked = $(".limit1:checkbox:checked");
    if (checked.length >= 4) {
		alert("no more than 3 tags");
		$(this).attr('checked', false);
    }

  });
});	
$(function() {
  $(".limit2:checkbox").click(function() {
    var checked = $(".limit2:checkbox:checked");
    if (checked.length >= 4) {
		alert("no more than 3 tags");
		$(this).attr('checked', false);
    }

  });
});	

//180329 add by lydia
$(function(){
	$("#upload").submit(function(e) {
		 var self = this;
		 e.preventDefault();
		 var temp = $('#upload').serializeArray();
		 if (temp.length == 1){
			displayerror();
			return false;
		 }else{ 
			self.submit();
		 }		 
	});
});

//180329 add by lydia
$(function(){
	$("#uploadurl").submit(function(e) {
		 var self = this;
		 e.preventDefault();
		 var temp = $('#uploadurl').serializeArray();
		 if (temp.length == 1){
			displayerror();
			return false;
		 }else{ 
			self.submit();
		 }		 
	});
});
//180329 add by lydia
$(document).ready(function(){
	$(".displayerror_upload").hide();
	$('#title').attr('readonly', true);
	$('#datepicker').attr('readonly', true);
	$('#datepicker').val($.datepicker.formatDate('yy-mm-dd', new Date()));
	$('#notetext').attr('readonly', true);
});

//180329 add by lydia
function displayerror(){
	$(".displayerror_upload").show();
	document.getElementById("errormessage_upload").innerHTML = 'Please select at least one mood tag';
}

//180330 add by lydia
function openDiary(base_path,mediaid,img,url){
	clean();
	targetMediaid = mediaid;
	base_path_global = base_path;
	$('.canvas').css('background-image',"url(\'"+img+"\')");
	$('#mediasource').attr("href", url);
	var request = JSON.stringify({mediaid: mediaid});
	var path = base_path.concat('/getNoteinfo');
	$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { request : request },					
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res['result']){ //modify node
						$("#btn1").html("Modify");
						$("#btn4").show();
						$("#btn2").attr("onclick","modifyNote()");
						$("#btn1").attr("onclick","startModification()");
						$(".txt").html("Click \"Modify\" to make changes");
						$('#title').val(res['notelist'][0]['noteset'][0]['notetitle']);
						title_bp = res['notelist'][0]['noteset'][0]['notetitle'];
						$('#datepicker').val(res['notelist'][0]['noteset'][0]['notedate']);
						date_bp = res['notelist'][0]['noteset'][0]['notedate'];
						$('#notetext').val(res['notelist'][0]['noteset'][0]['note']);
						note_bp = res['notelist'][0]['noteset'][0]['note'];
						noteid = res['notelist'][0]['noteset'][0]['noteid'];
					}else{ //create new node
						$("#btn1").html("Create");
						$("#btn4").hide();
						$("#btn2").attr("onclick","createNote()");
						$(".txt").html("Click \"Create\" to write your diary");
						$("#btn1").attr("onclick","startCreation()");
					}
				}
			}
		);
		
	var path = base_path.concat('/getMood');
	$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { request : request },					
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res['result']){ //modify node
						moods = res['moodlist'];
						for(var i=0;i<res['moodlist'].length;++i){
							$("#moodlist").append("<li class=\"rqtags_content\"><div class=\"rqtags_words\">"+res['moodlist'][i]+"</div></li>");
						}
					}
				}
			}
		);
	
}

//180330 add by lydia
function createNote(){
	var notetext = $("#notetext").val();
	var notetitle = $("#title").val();
	var notedate = $("#datepicker").val();
	var temp = new Date();
	var time = temp.toTimeString();
	var notetime = time.split(' ')[0];
	var mood = moods;
	var request = JSON.stringify({mediaid: targetMediaid,notetext:notetext,notetitle:notetitle,notedate:notedate,notetime:notetime,mood:mood});
	var path = base_path_global.concat('/createnote');
	$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { request : request },					
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res['result']){ //modify node
						$("#message").html("successful!");
						$("#btn1").html("Modify");
						$("#btn4").show();
						$("#btn2").attr("onclick","modifyNote()");
						$("#btn1").attr("onclick","startModification()");
						$(".txt").html("Click \"Modify\" to make changes");
						noteid = res['noteid'];
					}else{ //create new node
						$("#message").html("fail!");
					}
				}
			}
		);
}

//180330 add by lydia
function startCreation(){
	$('#title').attr('readonly', false);
	$('#datepicker').attr('readonly', false);
	$("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
	$('#notetext').attr('readonly', false);
	
}

//180330 add by lydia
function clean(){
	$('#title').val('');
	$('#title').attr('readonly', true);
	$('#datepicker').attr('readonly', true);
	$('#datepicker').val($.datepicker.formatDate('yy-mm-dd', new Date()));
	$('#notetext').attr('readonly', true);
	$('#notetext').val('');
	$("#message").html("");
	$("#moodlist").html("");
}

//180330 add by lydia
function startModification(){
	$('#title').attr('readonly', false);
	$('#datepicker').attr('readonly', false);
	$("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
	$('#notetext').attr('readonly', false);
}

//180330 add by lydia
function modifyNote(){
	var notetext = $("#notetext").val();
	var notetitle = $("#title").val();
	var notedate = $("#datepicker").val();
	var temp = new Date();
	var time = temp.toTimeString();
	var notetime = time.split(' ')[0];
	var mood = moods;
	var request = JSON.stringify({noteid: noteid,notetext:notetext,notetitle:notetitle,notedate:notedate,notetime:notetime,mood:mood});
	var path = base_path_global.concat('/modifynote');
	$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { request : request },					
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res['result']){ //modify node
						$("#message").html("successful!");
					}else{ //create new node
						$("#message").html("fail!");
						$('#title').val(title_bp);
						$('#datepicker').val(date_bp);
						$('#notetext').val(note_bp);
					}
				}
			}
		);
	
}

//180330 add by lydia
function deleteNote(){
	var request = JSON.stringify({noteid: noteid});
	var path = base_path_global.concat('/deletenote');
	$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { request : request },					
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res['result']){ //clean and creation
						clean();
						$("#btn1").html("Create");
						$("#btn4").hide();
						$("#btn2").attr("onclick","createNote()");
						$(".txt").html("Click \"Create\" to write your diary");
						$("#btn1").attr("onclick","startCreation()");
						noteid = null;
					}else{ //create new node
						$("#message").html("fail!");
					}
				}
			}
		);
	
}