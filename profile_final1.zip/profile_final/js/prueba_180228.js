$(document).ready(function(){
	$(".category_item").click(function(){
		var category = $(this).attr("id");

		if(category === "all"){
			$(".mood_item").addClass("hide");
			$(".button_item").addClass("hide");//180226 add by lydia
			setTimeout(function(){
				$(".mood_item").removeClass("hide");
				$(".button_item").removeClass("hide"); //180226 add by lydia
			}, 300);
		} else {
			$(".mood_item").addClass("hide");
			$(".button_item").addClass("hide"); //180226 add by lydia
			setTimeout(function(){
				$("." + category).removeClass("hide");
			}, 300);

		}
	});

	// the heart button
	$('.like-toggle').click(function() {
	$(this).toggleClass('active');

	});
});
