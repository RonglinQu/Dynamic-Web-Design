<!doctype html>
<html>
	<head>	
		<title>show image</title>	
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>	
		<script type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>/js/profile.js"></script>
	</head>
	<body>
		<a href="<?= ($img) ?>"><img src="<?= ($thumb) ?>" /></a>
		<form action = "<?= ($BASE) ?>/modifynote" method = "post">
			<input type = "date" name = "notedate" value="<?= ($notedate) ?>"/>
			<input type = "time" name = "notetime" value="<?= ($notetime) ?>"/>
			<input type = "text" name = "notetitle" placeholder="title" value="<?= ($notetitle) ?>"/>
			<input type = "text" name = "note" placeholder="note" value = "<?= ($note) ?>"/>
			<div class="checkbox">
				<?php foreach (($datalist?:[]) as $moodtype): ?>
					<li><input type="checkbox" class="limit1" name="mood[]" value="<?= ($moodtype['description']) ?>" <?= ($moodtype['checked']) ?>/><?= ($moodtype['description']) ?></li>
				<?php endforeach; ?>
			</div>
			<input type = "submit" value="modify"/>
			<input type = "hidden" name = "noteid" value="<?= ($noteid) ?>"/>
		</form>
	</body>
</html>
