 $('.fliper-btn').click(function(){
    $('.flip').find('.card').toggleClass('flipped');

});// JavaScript Document