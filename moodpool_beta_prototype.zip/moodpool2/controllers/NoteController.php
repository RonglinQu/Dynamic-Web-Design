<?php


class NoteController{
	private $notetable;
	private $notemood;
	
	public function __construct() {
		global $f3;						// needed for $f3->get() 
		$this->notetable = new DB\SQL\Mapper($f3->get('DB'),"notes");	
		$this->notemood = new DB\SQL\Mapper($f3->get('DB'),"notemood");												
	}
	
	public function putIntoDatabase($data) {
		global $f3;
		$this->notetable->noteid = strtoupper(md5(uniqid(rand(),true)));
		$noteid = $this->notetable->noteid;
		$this->notetable->userid = $_SESSION['userinfo']['userid'];				
		$this->notetable->mediaid = $data['mediaid'];
		$this->notetable->notetitle = $data['notetitle'];
		$this->notetable->note = $data['notetext'];
		$this->notetable->createdate = date("Ymd");
		$this->notetable->createtime = date("H:i:s");
		$this->notetable->notedate = $data['notedate'];
		$this->notetable->notetime = $data['notetime'];
		$this->notetable->save();		// save new record with these fields
		
		foreach ($data['mood'] as $item){
			$this->notemood->noteid =  $this->notetable->noteid;
			$moodtags = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
			$moodtags->load(array('description=?',$item));
			$this->notemood->mood = $moodtags->moodtypeid;
			$this->notemood->save();
			$this->notemood->reset();
		}
		return $noteid;
	}
	
	public function getNotes($mediaid){
		global $f3;
		$result = array();
		$is = new ImageServer;
		//$fapi = new FlickrAPI();
		$resultset = array();
		$noteinfo = new DB\SQL\Mapper($f3->get('DB'),"noteinfo");
		$moodtypemapper = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		$mediamapper = new DB\SQL\Mapper($f3->get('DB'),"mediacollections");
		//img,thumbnail,notetitle,note,notedate,notetime,moodtags
		if(empty($mediaid)){ //show all
			$mediaidset = $noteinfo->find(array('userid=?',$_SESSION['userinfo']['userid']));
			foreach ($mediaidset as $mediaiditem){
				$noteresultset = array();
				$mediamapper->load(array('mediaid=?',$mediaiditem->mediaid));
				$noteset = $this->notetable->find(array('mediaid=? AND userid=?',$mediaiditem->mediaid,$_SESSION['userinfo']['userid']));
				foreach ($noteset as $note){
					$noteresult = array();
					$noteresult['noteid'] = $note->noteid;
					$noteresult['notetitle'] = $note->notetitle;
					$noteresult['note'] = $note->note;
					$noteresult['notedate'] = $note->notedate;
					$noteresult['notetime'] = $note->notetime;
					$moodtags = array();
					//moodtags
					$moodset = $this->notemood->find(array('noteid=?',$note->noteid));
					foreach ($moodset as $item){
						$moodtypemapper->load(array('moodtypeid=?',$item->mood));
						array_push($moodtags,$moodtypemapper->description);
					}
					$noteresult['moodtags'] = $moodtags;
					array_push($noteresultset,$noteresult);
				}
				$result['noteset'] = $noteresultset;
				$result['mediaid'] = $mediaiditem->mediaid;
				/*if(!empty($mediamapper->recomid)){ //user upload
					$result['img'] = $f3->get("BASE")."/".$mediamapper->url;
					$result['thumbnail'] = $f3->get('UPLOADS'). "/thumb/" .$is->thumbFile($mediamapper->url);
				}else{ //user liked
					$result["img"] = $mediamapper->url;
					$thumb = $fapi->createThumbnail([$result["img"]]);
					$result["thumbnail"] = $thumb[0];
				}*/
				$temp = $is->getImageViaMediaid($mediamapper->mediaid);
				$result["img"] = $temp["img"];
				$result["thumbnail"] = $temp["thumbnail"];
				array_push($resultset,$result);
			}
		}else{ //show note based on mediaid
			if($noteinfo->count(array('userid=? AND mediaid=?',$_SESSION['userinfo']['userid'],$mediaid))){
				$noteresultset = array();
				$mediamapper->load(array('mediaid=?',$mediaid));
				$noteset = $this->notetable->find(array('mediaid=? AND userid=?',$mediaid,$_SESSION['userinfo']['userid']));
				foreach ($noteset as $note){
					$noteresult = array();
					$noteresult['noteid'] = $note->noteid;
					$noteresult['notetitle'] = $note->notetitle;
					$noteresult['note'] = $note->note;
					$noteresult['notedate'] = $note->notedate;
					$noteresult['notetime'] = $note->notetime;
					$moodtags = array();
					//moodtags
					$moodset = $this->notemood->find(array('noteid=?',$note->noteid));
					foreach ($moodset as $item){
						$moodtypemapper->load(array('moodtypeid=?',$item->mood));
						array_push($moodtags,$moodtypemapper->description);
					}
					$noteresult['moodtags'] = $moodtags;
					array_push($noteresultset,$noteresult);
				}
				$result['noteset'] = $noteresultset;
				$result['mediaid'] = $mediaid;
				/*if(!empty($mediamapper->recomid)){ //user upload
					$result['img'] = $f3->get("BASE")."/".$mediamapper->url;
					$result['thumbnail'] = $f3->get('UPLOADS'). "/thumb/" .$is->thumbFile($mediamapper->url);
				}else{ //user liked
					$result["img"] = $mediamapper->url;
					$thumb = $fapi->createThumbnail([$result["img"]]);
					$result["thumbnail"] = $thumb[0];
				}*/
				$temp = $is->getImageViaMediaid($mediaid);
				$result["img"] = $temp["img"];
				$result["thumbnail"] = $temp["thumbnail"];
				array_push($resultset,$result);
			}
		}
		return $resultset;
	}
	
	//180313 add by lydia
	public function getMediaid($noteid){
		$result = $this->notetable->load(array('noteid=?',$noteid));
		return $result->mediaid;
	}
	
	//180313 add by lydia
	public function getNoteInfo($noteid){
		global $f3;
		$note = $this->notetable->load(array('noteid=?',$noteid));
		$result['notetitle'] = $note->notetitle;
		$result['note'] = $note->note;
		$result['notedate'] = $note->notedate;
		$result['notetime'] = $note->notetime;
		$moodtags = array();
		$moodtypemapper = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		$moodset = $this->notemood->find(array('noteid=?',$noteid));
		foreach ($moodset as $item){
			$moodtypemapper->load(array('moodtypeid=?',$item->mood));
			array_push($moodtags,$moodtypemapper->description);
		}
		$result['moodtags'] = $moodtags;
		return $result;
	}
	
	//180313 add by lydia
	public function modifyNote($data){
		global $f3;
		$note = $this->notetable->load(array('noteid=?',$data['noteid']));
		$note->note = $data['notetext'];
		$note->notedate=$data['notedate'];
		$note->notetime = $data['notetime'];
		$note->notetitle = $data['notetitle'];
		$note->modifydate = date('Ymd');
		$note->modifytime = date("H:i:s");
		$note->save();
		$moodtypemapper = new DB\SQL\Mapper($f3->get('DB'),"moodtype");
		$moodset = $this->notemood->find(array('noteid=?',$data['noteid']));
		//if old tags are not in the new mood set, delete
		$found = false;
		foreach($moodset as $old){
			foreach($data['mood'] as $new){
				$moodtypemapper->load(array('description=?',$new));
				if($moodtypemapper->moodtypeid == $old->mood){
					$found = true;
					break;
				}
			}
			if(!$found){
				$old->erase();
			}
			$found = false;
		}
		//if new tags are not in the old mood set, insert
		$found = false;
		foreach($data['mood'] as $new){
			foreach($moodset as $old){
				$moodtypemapper->load(array('description=?',$new));
				if($moodtypemapper->moodtypeid == $old->mood){
					$found = true;
					break;
				}
			}
			if(!$found){
				$this->notemood->reset();
				$this->notemood->noteid = $data['noteid'];
				$moodtypemapper->load(array('description=?',$new));
				$this->notemood->mood = $moodtypemapper->moodtypeid;
				$this->notemood->save();
			}
			$found = false;
		}
	}
	
	//180313 add by lydia
	public function deleteNote($noteid){
		if($this->notetable->count(array('noteid=?',$noteid))){
			$notemood = $this->notemood->find(array('noteid=?',$noteid));
			foreach($notemood as $mood){
				$mood->erase();
			}
			$this->notetable->load(array('noteid=?',$noteid));
			$this->notetable->erase();
		}
	}
}

?>
