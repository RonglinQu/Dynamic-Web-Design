<!DOCTYPE html>
<html>
	<head>
	  <title><?= ($html_title) ?></title>
	  <meta charset='utf8' />
	  <link href="<?= ($BASE) ?>/<?= ($UI) ?>css/filtertest_style.css" rel="stylesheet" type="text/css">	
	  <!-- <link href="<?= ($BASE) ?>/<?= ($UI) ?>css/bootstrap.min.css" rel="stylesheet"> -->
	  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	  <script type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>js/layout.js"></script>
	</head>
	<div id="wrapper">	 
		<div class="col-md-12">	
			<div class="row">	
				<a href="<?= ($BASE) ?>/welcome"><img src="<?= ($BASE) ?>/<?= ($UI) ?>images/MP_logo_v2.png" class="img-logo"/></a>
				<!--<form name="form1" action="<?= ($BASE) ?>/<?= ($loginorout) ?>" method="get">  -->
				<a href = "<?= ($BASE) ?>/<?= ($loginorout) ?>">
					<button type="submit" class="btn btn-default btn-sm login-style" value = "<?= ($loginorout) ?>">
						<span class="glyphicon glyphicon-log-out"></span><b id = "loginout"><?= ($loginorout) ?></b>
					</button>
				</a>
				<!-- </form> -->
				<button type="button" class="user-style">
					<a href="<?= ($BASE) ?>/<?= ($username) ?>/home"><?= ($username) ?></a>
				</button>
				<!-- <form name="form2" action="<?= ($BASE) ?>/signup" method="get" id = "signup"> --> 
				<a href = "<?= ($BASE) ?>/signup"  id = "signup">
					<button type="submit" class="btn btn-default btn-sm login-style" value = "signup">
						<span class="glyphicon glyphicon-log-out"></span>signup
					</button>
					<script type="text/javascript">
						signuphidden();
					</script>
				</a>
				<!-- </form> -->
				<body>
				  <?php echo $this->render($content,NULL,get_defined_vars(),0); ?>
				</body>
			</div>
		</div>
	</div>
</html>
