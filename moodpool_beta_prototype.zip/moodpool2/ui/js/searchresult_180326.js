var loadmorepage = 1;

function passInf(key,base_path,title,url,ui){
	//if(document.getElementById("button".concat(key)).innerHTML=="like"){	
	if(document.getElementById("button".concat(key)).attributes['name'].value == "like"){
		var moodtag = document.getElementById("moodtag").innerHTML;
		var img = document.getElementById("img".concat(key)).href;
		//var url = document.getElementById("url".concat(key)).href;
		//var title = document.getElementById("title".concat(key)).innerHTML;
		var iteminfo = JSON.stringify({ moodtag: moodtag, img: img,url:url,title:title });
		var response = new Array();
		var path = base_path.concat('/like');
		$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { imageinfo : iteminfo },					
				success: function(response) { 
					var res = $.parseJSON(response);
					if(res.result != 1){
						$("#response").html(res.message);
					}else{
						//document.getElementById("button".concat(key)).innerHTML = "unlike";
						document.getElementById("button".concat(key)).setAttribute("name","unlike");
						document.getElementById("button".concat(key)).value = res.message;
						document.getElementById("button".concat(key)).innerHTML = "<img src=\""+base_path+"/"+ui+"/images/heart2.svg\" height=\"35\" width=\"35\"/>";
					}
				}
			}
		);
	}else{
		var mediaid = document.getElementById("button".concat(key)).value;
		var iteminfo = JSON.stringify({ mediaid: mediaid});
		var path = base_path.concat('/unlike');
		$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { mediaid : iteminfo }, 
				success: function(response) { 
					if(response != 1){
						$("#response").html(response);
					}else{
						//document.getElementById("button".concat(key)).innerHTML = "like";
						document.getElementById("button".concat(key)).setAttribute("name","like");
						document.getElementById("button".concat(key)).innerHTML = "<img src=\""+base_path+"/"+ui+"/images/heart1.svg\" height=\"35\" width=\"35\"/>";
					}
				}
			}
		);
	}
}
function liked(key,uiurl) {
	if(document.getElementById("button".concat(key)).innerHTML==true){
		//document.getElementById("button".concat(key)).innerHTML = "unlike";
		document.getElementById("button".concat(key)).innerHTML = "<img src=\""+uiurl+"/images/heart2.svg\" height=\"35\" width=\"35\"/>";
		document.getElementById("button".concat(key)).setAttribute("name","unlike");
	}else{
		//document.getElementById("button".concat(key)).innerHTML = "like";
		document.getElementById("button".concat(key)).innerHTML = "<img src=\""+uiurl+"/images/heart1.svg\" height=\"35\" width=\"35\"/>";
		document.getElementById("button".concat(key)).setAttribute("name","like");
	}
}

//180316 add by lydia
function loadmore(base_path,moodtag) {
	++loadmorepage;
	var iteminfo = JSON.stringify({ moodtag: moodtag, page:loadmorepage});
	var path = base_path.concat('/loadmore');
	$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { loadmore : iteminfo },					
				success: function(response) { 
					var res = $.parseJSON(response);
					$("div.block_container").append(res['html']);
				}
			}
		);
}
