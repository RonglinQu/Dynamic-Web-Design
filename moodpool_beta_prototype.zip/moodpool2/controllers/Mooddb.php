<?php
//180316 lydia add predictive search function
class Mooddb {
	private $mapper;
	
	public function __construct() {
		global $f3;						// needed for $f3->get() 
		$this->mapper = new DB\SQL\Mapper($f3->get('DB'),"moodtype");	// create DB query mapper object
																			// for the "moodtype" table
	}
	
	public function getMood() {
		$list = $this->mapper->find();
		return $list;
	}
	
	public function checkMood($mood) {
		$temp = trim(strtolower($mood));
		if($this->mapper->count(array('description=?',$temp))==0){
			return 1;
		}else{
			return 0;
		}
	}
	
	//180316 add by lydia
	public function predict($str){
		$query = '%'.$str.'%';
		$result = $this->mapper->find(array('description like ?',$query));
		return $result;
	}
	
	//180316 add by lydia
	public function getMoodviaMediaid($mediaid){
		global $f3;
		$personalmood = new DB\SQL\Mapper($f3->get('DB'),"personalmood");
		$result = array();
		$list = $personalmood->find(array('userid=? AND mediaid=?',$_SESSION['userinfo']['userid'],$mediaid));
		foreach ($list as $item){
			$this->mapper->load(array('moodtypeid = ?',$item->mood));
			array_push($result,$this->mapper->description);
		}
		return $result;
	}
}

?>
