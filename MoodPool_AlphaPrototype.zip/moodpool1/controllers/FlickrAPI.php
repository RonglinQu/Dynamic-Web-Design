<?php

class FlickrAPI {
	
	private $key = "d497fdb7e29545410d6da8acf8dafee0";
	private $number_per_page = 20;
	
	
	public function __construct() {}
	
	public function makingRequest($tag) {

		$request =  "https://api.flickr.com/services/rest?&method=flickr.photos.search".
					//"&api_key=".$this->key."&tags=".$tag."&extras=url_sq,url_m&per_page=".$this->number_per_page."&format=json&nojsoncallback=1";
					"&api_key=".$this->key."&tags=".$tag."&extras=url_sq,url_m&per_page=".$this->number_per_page;
		return $request;
	}
	
	public function load($request) {
		// for more on cURL see http://php.net/manual/en/book.curl.php and http://blog.unitedheroes.net/curl/
		$crl = curl_init(); // creating a curl object
		$timeout = 10;
		curl_setopt ($crl, CURLOPT_URL,$request);
		curl_setopt ($crl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($crl, CURLOPT_CONNECTTIMEOUT, $timeout);
		
		$xml_to_parse = curl_exec($crl);
		
		curl_close($crl); // closing the crl object
		
		$parsed_xml = simplexml_load_string($xml_to_parse);
		$items = $parsed_xml->photos->photo; // traversing the xml nodes to count how many photos were retrieved

		//echo htmlspecialchars($xml_to_parse);//show XML

		return $items;
	}
	
	public function getingPictures($items){
		
		$numOfItems = count($items);
		$returnrecord = array();
		$img = array();
		if($numOfItems>0){ // yes, some items were retrieved
			foreach($items as $current){
				$record = array();
				//$record['img_m'] = "http://farm".$current['farm'].".static.flickr.com/".$current['server']."/".$current['id']."_".$current['secret']."_m.jpg";
				$record['img'] = "http://farm".$current['farm'].".static.flickr.com/".$current['server']."/".$current['id']."_".$current['secret'].".jpg";
				//$record['img_m'] = $this->createThumbnail($record['img']);
				$record['url'] = "http://www.flickr.com/photos/".$current['owner']."/".$current['id'];
				$record['title'] = $current['title'];
				array_push($returnrecord,$record);
				array_push($img,$record['img']);
			}
		}
		$return_img = $this->createThumbnail($img);
		for($i=0;$i<count($returnrecord);++$i){
			$returnrecord[$i]["img_m"] = $return_img[$i];
		}
		return $returnrecord;
	}
	
	public function createThumbnail($url){
		//$image = file_get_contents($url);
		global $f3;
		$thumbsize_width = 200;
		$thumbsize_height = 175;
		$x_start = 0;
		$y_start = 0;
		// Get new dimensions
		//list($width_orig, $height_orig) = getimagesize($url);
		
		$crl_container = array();
		$path_array = array();
		$timeout = 10;
		foreach($url as $item){
			$crl = curl_init();
			curl_setopt ($crl, CURLOPT_URL,$item);
			curl_setopt ($crl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt ($crl, CURLOPT_CONNECTTIMEOUT, $timeout);
			array_push($crl_container,$crl);
			$filename = basename($item);   
			$path = $f3->get('TEMP')."thumb/thumb-".date('Ymd').date('His').$filename;
			array_push($path_array,$path);
		}
		$crl_image = curl_multi_init();
		foreach($crl_container as $item){
			curl_multi_add_handle($crl_image,$item);
		}
		$active = null;
		//execute the handles
		do {
			curl_multi_exec($crl_image,$running);
		} while($running > 0);
		$image = array();
		$i = 0;
		foreach ($crl_container as $item) {
			$image = imagecreatefromstring(curl_multi_getcontent($item));
			$image_thumb = $this->imagecrop($image, ['x' => x_start, 'y' => y_start, 'width' => $thumbsize_width, 'height' => $thumbsize_height]);
			imagejpeg($image_thumb, $path_array[$i]);
			//array_push($image, imagecreatefromstring(curl_multi_getcontent($item)));
			curl_multi_remove_handle($crl_image, $item);
			$i++;
		}
		/*$crl_image = curl_init(); // creating a curl object
		$timeout = 10;
		curl_setopt ($crl_image, CURLOPT_URL,$url);
		curl_setopt ($crl_image, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($crl_image, CURLOPT_CONNECTTIMEOUT, $timeout);
		
		$string = curl_exec($crl_image);
		
		curl_close($crl_image); // closing the crl object*/

		//$image = imagecreatefromstring($string);
		//$image = imagecreatefromjpeg($content);
		// Resample
		//$image_p = imagecreatetruecolor($width, $height);
		/*switch ($type) {
		  case "jpeg":
			$image = imagecreatefromjpeg($filename);
			break;
		  case "png":
			$image = imagecreatefrompng($filename);
			break;
		  case "gif":
			$image = imagecreatefromgif($filename);
			break;
		  default:
			$data = file_get_contents($filename);
			$image = imagecreatefromstring($data);
		}*/
		//imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
		//$image_thumb = imagecrop($image, ['x' => x_start, 'y' => y_start, 'width' => $thumbsize_width, 'height' => $thumbsize_height]);

		// Output
		// Notice this is always a jpeg image.  We could also have made others, but this seems OK.
		//imagejpeg($image_p, $thumbfile);
		//$filename = basename($url);   
		//$path = $f3->get('TEMP')."thumb/thumb-".date('Ymd').date('His').$filename;
		//imagejpeg($image_thumb, $path);
		return $path_array;
	}
	
	function imagecrop($image, array $rect)
	{
		$result = imagecreatetruecolor($rect['width'], $rect['height']);
		imagecopy(
			$result,
			$image,
			0,
			0,
			(int)$rect['x'],
			(int)$rect['y'],
			(int)$rect['width'],
			(int)$rect['height']
		);
		return $result;
	}
	
}

?>
