<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<!-- Bootstrap -->
<!-- <link href="<?= ($BASE) ?>/<?= ($UI) ?>css/bootstrap.min.css" rel="stylesheet"	-->
<!-- <link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/flatly/bootstrap.min.css" rel="stylesheet"> -->
<!--<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->
<!-- style MODAL 2-->	
<!--<link href="<?= ($BASE) ?>/<?= ($UI) ?>/css/lightbox.css" rel="stylesheet" type="text/css"> -->
<!-- Stylesheet CSS-->	
<link href="<?= ($BASE) ?>/<?= ($UI) ?>css/filtertest_style.css" rel="stylesheet" type="text/css">
<!--<link rel="stylesheet" href="<?= ($BASE) ?>/<?= ($UI) ?>/css/main.css" type="text/css"> -->
<!--180329 add by lydia -->
<link rel="stylesheet" href="<?= ($BASE) ?>/<?= ($UI) ?>/css/profileerror.css" type="text/css">
<!-- JavaScripts -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>	
<script src="<?= ($BASE) ?>/<?= ($UI) ?>js/prueba.js"></script>
<!-- JavaScripts MODAL 2-->	
<!--<script type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>/js/lightbox.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->
<!-- JavaScripts CONTENT UPLOAD-->
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!--180315 add by lydia -->
<script type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>/js/profile.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- 180329 added by Ronglin  -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!--<link rel="stylesheet" href="https://resources/demos/style.css"> -->

<link rel="stylesheet" href="<?= ($BASE) ?>/<?= ($UI) ?>/css/diary.css" media="screen" type="text/css" /> 

	
<title>Mood Pool Draft</title>	
</head>
<body> 	
<div class="col-md-12">
	<h3 class="subtitles"><?= ($username) ?>'s Profile</h3>	
	</div>
	
<div class="col-md-12">
	<h4 class="sub-subtitles"> Upload Mood </h4>
	<hr>
</div>	
<div class="col-md-12">
	<div class="row">
<!--<div id="columns">-->	<!-- other code 	
<!--<div class="block_container">-->
<!-- <form name="form" action="<?= ($BASE) ?>/upload" method="post">
	<input type="image" src="<?= ($BASE) ?>/<?= ($UI) ?>/images/upload.png" class="mood_item photo" alt="upload">
</form> -->
	<div class="center"><input type="image" data-toggle="modal" data-target="#squarespaceModal" src="<?= ($BASE) ?>/<?= ($UI) ?>/images/upload.png" class="btn btn-primary center-block"/></div>
	<!-- line modal -->
		<div class="modal fade" id="squarespaceModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
						<h3 class="modal-title" id="lineModalLabel">Upload a Mood</h3>
					</div>

					<div class="modal-body">
						<!--180329 add by lydia start -->
						<!-- Newly added error-->		  
						<br>				  
						<div class="error-text displayerror_upload">
							<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
							<strong>  Error!</strong> <label id='errormessage_upload'></label>
						</div>
						<!--180329 add by lydia end -->
						<!--180310 add by lydia start-->
						<ul class="nav nav-tabs">
							<li class="active"><a href="#file" data-toggle="tab">File</a></li>
							<li><a href="#url" data-toggle="tab">URL</a></li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane active" id="file">
						<!--180310 add by lydia end -->
								<!-- content goes here -->
								<form name="upload" id="upload" method="POST" action="<?= ($BASE) ?>/uploadImage" enctype="multipart/form-data">
									<div class="form-group">
										<label for="exampleInputFile">Choose file</label>
										<input type="file" name="picfile" id="exampleInputFile"/>
										<label for='picname'>Enter picture title</label>
										<input type="text" name="picname" id="picname" placeholder="Title for image" size="80"/><br />
										<p class="help-block">Tag your uploaded mood. Choose what moods best describe your uploaded file.</p>
									</div>
									<div class="checkbox">
										<label id="tagselection">
											<?php foreach (($datalist?:[]) as $moodtype): ?>
												<li><input class = "limit1" type="checkbox" name="mood[]" value="<?= ($moodtype['description']) ?>" /><?= ($moodtype['description']) ?></li>
											<?php endforeach; ?>
										</label>
									</div>
									<button type="submit" class="btn btn-default">Submit</button>
								</form>
							</div>
							<!--180310 add by lydia start -->
							<div class="tab-pane" id="url">
								<form name="uploadurl" id="uploadurl" method="POST" action="<?= ($BASE) ?>/uploadurl" enctype="multipart/form-data">
									<div class="form-group">
										<label for="inputurl">Enter URL</label>
										<input type="text" name="urllink" placeholder="URL" id="inputurl" size="80"/>
										<label for='picname'>Enter picture title</label>
										<input type="text" name="picname" id="picname" placeholder="Title for image" size="80"/><br />
										<p class="help-block">Tag your uploaded mood. Choose what moods best describe your uploaded file.</p>
									</div>
									<div class="checkbox">
										<label id="tagselection">
											<?php foreach (($datalist?:[]) as $moodtype): ?>
												<li><input class = "limit2" type="checkbox" name="mood[]" value="<?= ($moodtype['description']) ?>" /><?= ($moodtype['description']) ?></li>
											<?php endforeach; ?>
										</label>
									</div>
									<button type="submit" class="btn btn-default">Submit</button>
								</form>
							</div>
							<!--180310 add by lydia end-->
						</div>
					</div>
				</div>
				<!-- <div class="modal-footer">
					<div class="btn-group btn-group-justified" role="group" aria-label="group button">
						<div class="btn-group" role="group">
							<button type="button" class="btn btn-default" data-dismiss="modal"  role="button">Close</button>
						</div>
						<div class="btn-group btn-delete hidden" role="group">
							<button type="button" id="delImage" class="btn btn-default btn-hover-red" data-dismiss="modal"  role="button">Delete</button>
						</div>
						<div class="btn-group" role="group">
							<button type="button" id="saveImage" class="btn btn-default btn-hover-green" data-action="save" role="button">Save</button>
						</div>
					</div>
				</div> -->
			</div>
		</div>
	</div>
	<!-- <form name="form" action="<?= ($BASE) ?>/upload" method="post">
		<input type="image" src="<?= ($BASE) ?>/<?= ($UI) ?>/images/upload.png" class="mood_item photo" alt="upload">
	</form> -->
<!-- after class add the especific tag for the media -->
</div>
</div>
<!--</div>-->
		
<div class="col-md-12">
	<h4 class="sub-subtitles"> Favourites </h4>
	<hr>
	<div class="col-md-12">
	<div class="row"> 	
	<div class="category-continer">
		<p class="category_item item_style favorites_item" id="favorites_all">All Media </p>
		<p class="category_item item_style favorites_item" id="favorites_photo">Photos</p>
		<p class="category_item item_style favorites_item" id="favorites_video">Videos</p>
		<p class="category_item item_style favorites_item" id="favorites_music">Music</p>
		<p class="category_item item_style favorites_item" id="favorites_illustration">Illustration</p>
		<p class="category_item item_style favorites_item" id="favorites_article">Articles</p>
		<p class="category_item item_style favorites_item" id="favorites_book">Books</p>
	</div>
	</div>
	</div>
	<div class="row">	
		<div class="block_container">
			<?php foreach (($likedimages?:[]) as $imageinfo): ?>
				<!-- 180328 added by Ronglin   add the class of img -->
				<div id="imgdisplay">
					<img src="<?= ($BASE) ?>/<?= ($imageinfo['img_m']) ?>" class="favorite_mood_item favorites_photo favourites md-trigger" data-modal="modal-1" onclick="openDiary('<?= ($BASE) ?>','<?= ($imageinfo['mediaid']) ?>','<?= ($imageinfo['img']) ?>','<?= ($imageinfo['url']) ?>')"/>
					<!-- <p> <?= ($imageinfo['title']) ?>  (<a href="<?= ($BASE) ?>/unlike/<?= ($imageinfo['mediaid']) ?>">unlike</a>)</p>-->
					<!-- <div class="delete"> -->
					<p class="tags_words favorites_photo favorite_mood_item"><?= ($imageinfo['tags'][0]) ?></p>
					<button class='favorite_button_item favorites_photo transparent heart hearted' width="30px" height="30px"><a href="<?= ($BASE) ?>/unlike/<?= ($imageinfo['mediaid']) ?>"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/heart2.svg" height="35" width="35"/></a></button>
					<!-- </div> -->
					<!-- <?php foreach (($imageinfo['tags']?:[]) as $moodtag): ?> -->
					<!--<p class="tags_words"><?= ($imageinfo['tags'][0]) ?></p> -->
					<!--<?php endforeach; ?> -->
				</div>
			<?php endforeach; ?>
			<?php foreach (($likedmusic?:[]) as $musicinfo): ?>
				<div id="musicdisplay">
					<img src="<?= ($musicinfo['img']) ?>" class="favorite_mood_item favorites_music favourites md-trigger" width="175" height="214" data-modal="modal-1" onclick="openDiary('<?= ($BASE) ?>','<?= ($musicinfo['mediaid']) ?>','<?= ($musicinfo['img']) ?>','<?= ($musicinfo['url']) ?>')"/>
					<!-- <p> <?= ($imageinfo['title']) ?>  (<a href="<?= ($BASE) ?>/unlike/<?= ($imageinfo['mediaid']) ?>">unlike</a>)</p>-->
					<!-- <div class="delete"> -->
					<p class="tags_words favorites_music favorite_mood_item"><?= ($musicinfo['tags'][0]) ?></p>
					<button class='favorite_button_item favorites_music transparent heart hearted' width="30px" height="30px"><a href="<?= ($BASE) ?>/unlike/<?= ($musicinfo['mediaid']) ?>"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/heart2.svg" height="35" width="35"/></a></button>
					<!-- </div> -->
					<!-- <?php foreach (($imageinfo['tags']?:[]) as $moodtag): ?>
						<label><?= ($moodtag) ?></label>
					<?php endforeach; ?> -->
				</div>
			<?php endforeach; ?>
		<!-- <img src="http://via.placeholder.com/200x175" class="mood_item photo">
		<img src="http://via.placeholder.com/200x175" class="mood_item video">
		<img src="http://via.placeholder.com/200x175" class="mood_item photo">
		<img src="http://via.placeholder.com/200x175" class="mood_item video">
		<img src="http://via.placeholder.com/200x175" class="mood_item music">
		<img src="http://via.placeholder.com/200x175" class="mood_item book"> -->
		</div>
	</div>
</div>
	
<div class="col-md-12">
	<h4 class="sub-subtitles"> My Moods </h4>
	<hr>
	<div class="col-md-12">
	<div class="row"> 	
	<div class="category-continer">
		<p class="category_item item_style upload_item" id="upload_all">All Media </p>
		<p class="category_item item_style upload_item" id="upload_photo">Photos</p>
		<p class="category_item item_style upload_item" id="upload_video">Videos</p>
		<p class="category_item item_style upload_item" id="upload_music">Music</p>
		<p class="category_item item_style upload_item" id="upload_illustration">Illustration</p>
		<p class="category_item item_style upload_item" id="upload_article">Articles</p>
		<p class="category_item item_style upload_item" id="upload_book">Books</p>
	</div>
	</div>
	</div>
	<div class="row">
		<div class="block_container">
			<?php foreach (($likeddatalist?:[]) as $item): ?>
				<div id="imgdisplay">
					<img src="<?= ($BASE) ?>/<?= ($item['thumbNail']) ?>" class="upload_mood_item upload_photo favourites md-trigger" data-modal="modal-1" onclick="openDiary('<?= ($BASE) ?>','<?= ($item['mediaid']) ?>','<?= ($BASE) ?>/<?= ($item['url']) ?>','<?= ($BASE) ?>/<?= ($item['url']) ?>')"/>
					<!-- <p><?= ($item['title']) ?>  (<a href="<?= ($BASE) ?>/delete/<?= ($item['recomid']) ?>">Delete?</a>)</p> -->
					<!--<div class="delete"> -->
					<p class="tags_words favorites_photo favorite_mood_item"><?= ($item['tags'][0]) ?></p>
					<button class='upload_button_item upload_photo transparent heart hearted' width="30px" height="30px"><a href="<?= ($BASE) ?>/delete/<?= ($item['recomid']) ?>">✖</a></button>
					<!--</div> -->
					<!--<?php foreach (($item['tags']?:[]) as $moodtag): ?>
						<label><?= ($moodtag) ?></label>
					<?php endforeach; ?> -->
				</div>
			<?php endforeach; ?>
				
			<!-- <img src="http://via.placeholder.com/200x175" class="mood_item photo">
			<img src="http://via.placeholder.com/200x175" class="mood_item music">
			<img src="http://via.placeholder.com/200x175" class="mood_item photo">
			<img src="http://via.placeholder.com/200x175" class="mood_item book"> -->
		</div>
	</div>
</div>
</div>
<!-- 180328 added by Ronglin  -->
	<div class="wholediary">
		<div class="md-modal md-effect-1" id="modal-1">
			<div class="md-content">

		<div id="profile">
		<div class="canvas">
		<canvas resize="true" hidpi="off" id="canvas-1"></canvas>

		</div>
		
		<div class="diary">
		<a id = "mediasource" href="">source</a>
		<div id="message"></div>
		<ul id = "moodlist">
		<!--<li class="rqtags_content">
		<div class="rqtags_words">Melancholy</div>
		</li>
		<li class="rqtags_content">
		<div class="rqtags_words">Sad</div>
		</li>-->
		</ul>
		<br /> <br>
		

		<form>
			<div>
				<span>Title: <input type="text" id="title" style="vertical-align:middle"></span>
				&nbsp;
				<span>Date: <input type="text" id="datepicker"></span>
				<textarea type='text' id="notetext" value='' class='textarea'/></textarea>
			</div>
		</form>

    <br>

		<div class="txt">Click "Create" to write your diary.</div>
		<br>
		<div class="btnedit">
		  <button id="btn1" >Create</button>
		  <button id="btn2" >Save</button>
		  <!--<span id="btn3">Modify</span>-->
		  <button id="btn4" onclick="deleteNote()">Delete</button>
		</div>

		<br>
		<!-- <button class="md-close">Exit</button> -->
		<span class="md-close exit"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/x-mark-gray.png" alt="" width='20px' height='20px'></span>

		</div>

		</div>  <!-- profile -->

		</div>
		</div>
		<!-- change the Diary button into images -->
		<!-- <button class="md-trigger" data-modal="modal-1">Diary</button> -->

		<div class="md-overlay"></div><!-- the overlay element -->

	</div>


  <!-- 180328 added by Ronglin  -->
  <!-- 180329 revised by Ronglin  -->
  <!--<script src="jquery.min.js" type="text/javascript"></script>-->
  <script>
  /*$(function(){
  	$(".txt").html('<textarea class="textarea" readonly>Click "Create" to write your diary.</textarea>');
  $("#btn1").click(function(){
  var txt1 = $(".txt").text();   
  var textarea = $("<textarea type='text'value='" + txt1 + "' class='textarea'/>");     //定义变量input
  $(".txt").html(textarea);       
  $("#btn2").click(function() {
  $(".txt").html(textarea.val())  
  });
  });
  });*/
  // date
  /*$( function() {
  $( "#datepicker" ).datepicker();
  } );*/

  // this is important for IEs
  var polyfilter_scriptpath = '/js/';

  </script>
  <script src="<?= ($BASE) ?>/<?= ($UI) ?>/js/index.js"></script>
</body>
</html>
