$(document).ready(function(){
	$(".category_item").click(function(){
		var category = $(this).attr("id");

		if(category === "all"){
			$(".mood_item").addClass("hide");
			$(".button_item").addClass("hide");//180226 add by lydia
			$(".allmediatags").addClass("hide");//180329 add by lydia
			setTimeout(function(){
				$(".mood_item").removeClass("hide");
				$(".button_item").removeClass("hide"); //180226 add by lydia
				$(".allmediatags").removeClass("hide");//180329 add by lydia
			}, 300);
		} else {
			$(".mood_item").addClass("hide");
			$(".button_item").addClass("hide"); //180226 add by lydia
			$(".allmediatags").addClass("hide");//180329 add by lydia
			setTimeout(function(){
				$("." + category).removeClass("hide");
			}, 300);

		}
	});

	// the heart button
	$('.like-toggle').click(function() {
	$(this).toggleClass('active');

	});
	
	//180326 add by lydia
	$(".favorites_item").click(function(){
		var category = $(this).attr("id");

		if(category === "favorites_all"){
			$(".favorite_mood_item").addClass("hide");
			$(".favorite_button_item").addClass("hide");//180226 add by lydia
			setTimeout(function(){
				$(".favorite_mood_item").removeClass("hide");
				$(".favorite_button_item").removeClass("hide"); //180226 add by lydia
			}, 300);
		} else {
			$(".favorite_mood_item").addClass("hide");
			$(".favorite_button_item").addClass("hide"); //180226 add by lydia
			setTimeout(function(){
				$("." + category).removeClass("hide");
			}, 300);

		}
	});
	
	//180326 add by lydia
	$(".upload_item").click(function(){
		var category = $(this).attr("id");

		if(category === "upload_all"){
			$(".upload_mood_item").addClass("hide");
			$(".upload_button_item").addClass("hide");//180226 add by lydia
			setTimeout(function(){
				$(".upload_mood_item").removeClass("hide");
				$(".upload_button_item").removeClass("hide"); //180226 add by lydia
			}, 300);
		} else {
			$(".upload_mood_item").addClass("hide");
			$(".upload_button_item").addClass("hide"); //180226 add by lydia
			setTimeout(function(){
				$("." + category).removeClass("hide");
			}, 300);

		}
	});
});
