function userhidden(user,login,logout){
	document.getElementById('user').style.visibility = user;
	document.getElementById('login').style.visibility = login;
	document.getElementById('logout').style.visibility = logout;
}

//180316 add by lydia
function showResult(str,base_path) {
	if (str.length==0) { 
		//document.getElementById("livesearch").innerHTML="";
		//document.getElementById("livesearch").style.border="0px";
		lost();
		return;
	}
	var iteminfo = JSON.stringify({str:str});
	var path = base_path.concat('/predict');
	$.ajax(
			{ 
				type: "POST", 
				url: path, 
				data: { predict : iteminfo },					
				success: function(response) { 
					var res = $.parseJSON(response);
					$("#livesearch").html(""); //删除原有数据
					if (res['result']) {
						for (var i = 0; i < $(res['data']).length; i++) {
							$("#livesearch").append('<div class="item" onclick="mousedown(this)" tabindex="-1">' + res['data'][i] + '</div>');
						}	
					}else{
						$("#livesearch").append('<div class="item">' + res['data'] + '</div>');
					}
					$("#livesearch").slideDown();
				}
			}
	);
}
//180316 add by lydia
function mousedown(object) {
   $("#tag").val($(object).text());
   $("#livesearch").fadeOut();
}
//180316 add by lydia
function lost() {

		$("#livesearch").fadeOut();
   
}
//180316 add by lydia
function addToSearchBar($value){
	document.getElementById("tag").value=$value;
}