<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<!-- Stylesheet CSS-->	
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<link href="<?= ($BASE) ?>/<?= ($UI) ?>/css/MP_login.css" rel="stylesheet" type="text/css">
		<!-- JavaScripts -->	
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>	
		<title>Login and Sign Up</title>
	</head>
	<body>
	<div class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="flip">
					<div class="card"> 
						<div class="face front"> 
							<div class="panel panel-default">
								<form class="form-horizontal" id="form1" name="form1" method="post" action="<?= ($BASE) ?>/signup">
									<br>
									<a href="<?= ($BASE) ?>/welcome"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/MP_logo_v2.png" class="img-logo resize-logo"/></a>
									<br>
									<label>Create New User</label>
									<input name="email" class="form-control" placeholder="Email"/>
									<input name="username" class="form-control" placeholder="Username"/>
									<input name="password" class="form-control" placeholder="Password"/>
									<button type="submit" class="btn btn-primary btn-block">SIGN UP</button>
									<p class="text-center">
										<a href="#" class="fliper-btn">Already have an account?</a>
									</p>
								</form>
							</div>
						</div> 
						<div class="face back"> 
							<div class="panel panel-default">
								<form class="form-horizontal" id="form1" name="form1" method="post" action="<?= ($BASE) ?>/login">
									<br>
									<a href="<?= ($BASE) ?>/welcome"><img src="<?= ($BASE) ?>/<?= ($UI) ?>/images/MP_logo_v2.png" class="img-logo resize-logo"/></a>
									<br>
									<input name="usernameemail" class="form-control" placeholder="Username or Email address"/>
									<input name="password" class="form-control" placeholder="Password"/>
									<!-- <p class="text-right"><a href="">Forgot Password</a></p> -->
									<button type= "submit" class="btn btn-primary btn-block">LOG IN</button>
									<hr>
									<p class="text-center">
										<a href="#" class="fliper-btn">Create new account?</a>
									</p>
								</form>
							</div>
						</div>
					</div>   
				</div>
			</div>
			<div class="col-md-4"></div>
		</div>
	</div>

	</body>
	<script type="text/javascript" src="<?= ($BASE) ?>/<?= ($UI) ?>/js/javalogin.js"></script>
</html>
