<!DOCTYPE html>
<html>
   <head>
      <title><?= ($html_title) ?></title>
      <meta charset='utf8' />
   </head>
   <body>
      <?= ($result)."
" ?>
   </body>
</html>
